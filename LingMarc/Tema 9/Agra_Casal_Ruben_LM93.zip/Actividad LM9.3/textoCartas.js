let palos = ["oros", "espadas", "copas", "bastos"];

for (let i = 0; i < palos.length; i++) {
    for (let j = 1; j <= 12; j++) {
        let carta = document.createElement("p");
        carta.setAttribute("palo", palos[i]);
        carta.appendChild(document.createTextNode(j + " de " + palos[i]));
        document.body.appendChild(carta); 
    }
}


