package Rubent02;

import java.util.Scanner;
public class Ejercicio1_6 {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        double comidaDiaria, kilosPorAnimal, numAnimales;



        System.out.print("Introduzca la cantidad de alimento diaria disponible: ");
        comidaDiaria = entrada.nextFloat();

        System.out.print("\nIntroduzca el número de animales que hay en la granja: ");
        numAnimales = entrada.nextFloat();

        System.out.print("\nIntroduzca la cantidad de kilos que necesita consumir cada animal al día: ");
        kilosPorAnimal = entrada.nextFloat();

        double excedente = comidaDiaria - (kilosPorAnimal * numAnimales);
        double racion = comidaDiaria / numAnimales;

        if(comidaDiaria < (kilosPorAnimal * numAnimales)) {
            System.out.println("--------------------------------");
            System.out.println("¡Cantidad insuficiente!" +
                    "\nLa cantidad por ración que se repartirá para cada animal será de: " + racion + " kilos");
            System.out.println("El excedente de la comida de hoy fue de: 0 kilos");

        }else {
            System.out.println("--------------------------------");
            System.out.println("¡Cantidad necesaria suficiente!");
            System.out.println("\nEl excedente de la comida de hoy fue de: " + excedente + " kilos");
        }




    }
}
