package Rubent02;

import java.util.Scanner;
public class Ejercicio1_2 {
    public static void main(String[] args) {

        int num1;
        Scanner entrada = new Scanner(System.in);

        System.out.println("Introduce un número");
        num1 = entrada.nextInt();

        if(num1 == 0 ||num1 % 2 == 0) {
            System.out.println(num1 + " es un número par.");
        }else {
            System.out.println(num1 + " es un número impar.");
        }
    }

}
