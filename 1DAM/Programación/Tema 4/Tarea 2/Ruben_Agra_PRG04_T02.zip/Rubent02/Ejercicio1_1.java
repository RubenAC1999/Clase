package Rubent02;

import java.util.Scanner;

public class Ejercicio1_1 {
    public static void main(String[] args){

        int num1;
        int num2;

        Scanner entrada = new Scanner(System.in);

        System.out.println("Introduce el primer número");
        num1 = entrada.nextInt();

        System.out.println("Introduce el segundo número");
        num2 = entrada.nextInt();

        if(num1 % num2 == 0){
            System.out.println(num1 + " es múltiplo de " + num2);

        }else{
            System.out.println(num1 + " no es múltiplo de " + num2);
        }
    }
}
