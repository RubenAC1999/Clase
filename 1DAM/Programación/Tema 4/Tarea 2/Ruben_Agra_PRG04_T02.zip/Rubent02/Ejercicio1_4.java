package Rubent02;

import java.util.Scanner;
public class Ejercicio1_4 {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        double a, b, c;

        System.out.println("Introduce el coeficiente de a");
        a = entrada.nextDouble();

        System.out.println("Introduce el coeficiente de b");
        b = entrada.nextDouble();

        System.out.println("Introduce el coeficiente de c");
        c = entrada.nextDouble();

        double discriminante = Math.sqrt((b * b) -4 * a * c);

        if(a == 0 && b == 0) {
            System.out.println("a y b no pueden ser 0 simultáneamente");

        }else if(a == 0) {
            double solucion1 = -c/b;
            System.out.printf("Única solución: %.2f", solucion1);

        }else if(discriminante < 0) {
            System.out.println("La ecuación no tiene soluciones reales");

        }else if(discriminante == 0) {
            double solucion1 = -b / (2 * a);
            System.out.printf("Única solución: %.2f", solucion1);

        }else {
            double solucion1 = (-b + discriminante) / (2 * a);
            double solucion2 = (-b - discriminante) / (2 * a);
            System.out.printf("Las soluciones de esta ecuación son: \n%.2f \n%.2f", solucion1, solucion2 );
        }
    }
}

