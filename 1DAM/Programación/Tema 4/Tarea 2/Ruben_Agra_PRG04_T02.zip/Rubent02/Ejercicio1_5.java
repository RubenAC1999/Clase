package Rubent02;

import java.util.Scanner;

public class Ejercicio1_5 {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        String letras = "TRWAGMYFPDXBNJZSQVHLCKE";
        String dni;

        System.out.println("Introduce tu DNI");
        dni = entrada.nextLine();

        if (dni.length() != 8) {
            System.out.println("DNI incorrecto, inténtelo de nuevo.");
            main(null);
        }else {
            int resto = Integer.parseInt(dni)%23;
            char letraDNI = letras.charAt((resto));
            System.out.println(letraDNI);
        }
    }
}
