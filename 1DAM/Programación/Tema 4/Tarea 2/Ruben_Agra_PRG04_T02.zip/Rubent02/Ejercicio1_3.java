package Rubent02;

import java.util.Scanner;

public class Ejercicio1_3 {
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        float num1, num2, num3;

        System.out.println("Introduce el primer número");
        num1 = entrada.nextFloat();

        System.out.println("Introduce el segundo número");
        num2 = entrada.nextFloat();

        System.out.println("Introduce el tercer número");
        num3 = entrada.nextFloat();

        if(num1 > num2 && num1 > num3) {
            System.out.println(num1 + " es el número mayor");
        }else if(num2 > num1 && num2 > num3) {
            System.out.println(num2 + " es el número mayor");
        }else if(num3 > num1 && num3 > num2) {
            System.out.println(num3 + " es el número mayor");
        }else {
            System.out.println("3 iguales");
        }
    }
}
