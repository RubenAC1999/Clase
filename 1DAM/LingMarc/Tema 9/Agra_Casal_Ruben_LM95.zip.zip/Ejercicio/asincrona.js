
/*Completa el resto de esta función para que cree una tabla, con las cabeceras y los datos del JSON*/
function crearTabla(responseText){
    const datosTabla = JSON.parse(responseText);
    document.querySelector("section").innerHTML = "";
    let section = document.createElement("section");
    document.body.appendChild(section);
    let table = document.createElement("table");
    section.appendChild(table);
    let cabecera = document.createElement("tr");
    table.appendChild(cabecera);

    let titulo = document.createElement("th");
    cabecera.appendChild(titulo);
    titulo.innerHTML = "Título";
    

    let ventas = document.createElement("th");
    cabecera.appendChild(ventas);
    ventas.innerHTML = "Ventas";

    let fechaSalida = document.createElement("th");
    cabecera.appendChild(fechaSalida);
    fechaSalida.innerHTML = "Fecha salida";

    for(let i = 0; i < datosTabla.discos.length; i++) {
        let fila = document.createElement("tr");
        table.appendChild(fila);
        let dato = document.createElement("td");
        fila.appendChild(dato);
        dato.innerHTML = datosTabla.discos[i].titulo;
        let dato2 = document.createElement("td");
        fila.appendChild(dato2);
        dato2.innerHTML = datosTabla.discos[i].ventas; 
        let dato3 = document.createElement("td");
        fila.appendChild(dato3);
        dato3.innerHTML = datosTabla.discos[i].salida;     
    }

}

document.getElementById("busqueda").onclick = leerJSON;

function leerJSON(){
    peticion = new XMLHttpRequest();
    peticion.onreadystatechange = function() {
        if (this.readyState == 4) {
            if (this.status == 200)
                crearTabla(this.responseText);
            else
                document.querySelector('div').innerHTML = "Error al acceder al fichero";
        }
    };
    peticion.open("GET", document.getElementById("nombreJson").value, true);
    peticion.send();
}

