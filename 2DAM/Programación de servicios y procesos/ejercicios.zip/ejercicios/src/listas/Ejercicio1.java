package listas;

import java.util.ArrayList;
import java.util.List;

import static java.util.Comparator.comparing;

// Crear una lista de números e invertirla
public class Ejercicio1 {
    public static void main(String[] args) {
        List<Integer> numbers = new ArrayList<>();

        for (int i = 0; i < 10; i++) {
            numbers.add(i);
        }

        System.out.println(numbers);

        numbers.sort(comparing(Integer::intValue).reversed());

        System.out.println(numbers);
    }
}
