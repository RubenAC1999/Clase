package listas;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.stream.Collectors;
// Crear una lista de números e imprimir los números pares y contarlos.
public class Ejercicio2 {
    public static void main(String[] args) {
        List<Integer> numbers = generateNumbers();

        List<Integer> evenNumbers = numbers.stream()
                .filter(n -> n % 2 == 0)
                .collect(Collectors.toList());


        System.out.println("Number list: " + numbers);
        System.out.println("Even number list: " + evenNumbers);
    }

    public static List<Integer> generateNumbers() {
        Random random = new Random();
        List<Integer> numbers = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            numbers.add(random.nextInt(100));
        }
        return numbers;
    }
}
