import java.sql.*;
import java.util.ArrayList;
import java.util.Scanner;

public class DBOperations {
    public static void main(String[] args) throws SQLException {
        showTables();
    }

    public static void showTables() throws SQLException {
        Scanner scanner = new Scanner(System.in);
        Connection connection = JDBC_Connection.connect();
        Statement statement = connection.createStatement();
        ResultSet result = statement.executeQuery("SHOW TABLES;");
        System.out.println("DB Operations menu");
        StringBuilder sb = new StringBuilder("--------------------\n| Tables in the DB |\n--------------------\n");

        ArrayList<String> tables = new ArrayList<>();
        while (result.next()) {
            String columnName = result.getString(1);
            sb.append(columnName);
            sb.append("\n");
            tables.add(columnName);
        }

        boolean tableFounded = false;
        do {
            System.out.println(sb);
            System.out.println("Indicate the table: ");
            String tableOption = scanner.nextLine();

            for (String table : tables) {
                if (tableOption.equals(table)) {
                    System.out.println("Table founded");
                    String tableSelected = tableOption;
                    tableFounded = true;
                    operationsMenu(tableSelected);
                    break;
                }
            }
            if (!tableFounded) {
                System.out.println("Table not founded, try again.");
            }
        } while (!tableFounded);


        result.close();
        statement.close();
        connection.close();
    }

    public static void operationsMenu(String table) throws SQLException {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Select an operation");
        System.out.println("=====================");
        System.out.println("1. Insert new row");
        System.out.println("2. Modify row");
        System.out.println("3. Navigate and view rows");
        System.out.println("4. Exit");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                insertData(table);
                break;
            case 2:
                showTableData(table);
                break;
            case 3:
                navigateTableData(table);
                break;
            case 4:
                System.exit(0);
        }
    }

    public static void insertData(String table) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        Connection connection = JDBC_Connection.connect();

        try {
            Statement statement = connection.createStatement();
            String query = "SHOW COLUMNS FROM " + table;
            ResultSet result = statement.executeQuery(query);
            ResultSetMetaData metaData = result.getMetaData();

            StringBuilder insertQueryColumns = new StringBuilder("INSERT INTO " + table + "(");
            StringBuilder insertQueryValues = new StringBuilder(") VALUES (");

            int numberOfColumns = metaData.getColumnCount();
            int index = 1;
            while (result.next()) {
                String columnType = metaData.getColumnTypeName(index);
                String columnName = result.getString(1);

                if (columnName.contains("fecha")) {
                    System.out.println("Insert data to " + columnName + " (yyyy-mm-dd)");
                } else {
                    System.out.println("Insert data to " + result.getString(1) + " (" + columnType + ")");
                }
                String value = scanner.nextLine();

                // appends para los stringBuilders del principio del método para ir construyendo la consulta.
                // si es la última columna, no añade una ',' al final.
                if (index < numberOfColumns) {
                    insertQueryColumns.append(columnName + ",");
                    insertQueryValues.append("'" + value + "',");
                } else {
                    insertQueryColumns.append(columnName);
                    insertQueryValues.append("'" + value + "'");
                }
                index++;
            }

            String insertQuery = insertQueryColumns.append(insertQueryValues + ");").toString();
            System.out.println(insertQuery);
            Statement insertStatement = connection.createStatement();
            int insertResult = insertStatement.executeUpdate(insertQuery);
            System.out.println("New row inserted successfully (" + insertResult + ")");

        } catch (SQLException ex) {
            System.err.println("SQL error: \n");
            ex.printStackTrace();
        } finally {
            connection.close();
        }

    }

    public static void updateMenu(String table, String primaryKey, String id) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select an operation");
        System.out.println("--------------------");
        System.out.println("1. Update row");
        System.out.println("2. Delete row");
        int option = scanner.nextInt();

        switch (option) {
            case 1 -> modifyRow(table, id);
            case 2 -> deleteRow(table, primaryKey, id);
        }
    }


    public static void showTableData(String table) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        Connection connection = JDBC_Connection.connect();

        try {
            Statement statement = connection.createStatement();
            String query = "SELECT * FROM " + table + " ORDER BY ";

            switch (table) {
                case "parkings" -> query += "ciudad ASC;";
                case "garajes" -> query += "tamanho ASC;";
                case "userCategorias" -> query += "nombre_categoria ASC;";
                case "usuario" -> query += "telefono ASC;";
                case "metodosPago" -> query += "nombre ASC;";
                case "historialAlquileres" -> query += "fechaFin ASC;";
            }

            ResultSet result = statement.executeQuery(query);
            ResultSetMetaData metaData = result.getMetaData();

            int columnCount = metaData.getColumnCount();
            System.out.println("\t" + table + " data");
            System.out.println("==========================");
            String primaryKey = null;

            // Impresión de nombre de las columnas.
            for (int i = 1; i <= columnCount; i++) {
                if (i == 1) {
                    primaryKey = metaData.getColumnName(i);
                }
                System.out.printf("%-32s", metaData.getColumnName(i));
            }

            // Impresión de los datos.
            System.out.println();
            while (result.next()) {
                for (int i = 1; i <= columnCount; i++) {
                    if (result.wasNull()) {
                        System.out.printf("%-32sSin datos");
                    } else if (i == 1) {
                        System.out.printf("%-32d", result.getInt(i));
                    } else {
                        System.out.printf("%-32s", result.getString(i));
                    }
                }
                System.out.println();
            }

            System.out.println("Indicate the id: ");
            String id = scanner.nextLine();
            while (!searchId(table, id)) {
                System.out.println("ID not founded, try again.");
                id = scanner.nextLine();
            }
            System.out.println("ID founded.");
            updateMenu(table, primaryKey, id);

            result.close();
            connection.close();

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            connection.close();
        }
    }

    public static void modifyRow(String table, String id) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        Connection connection = JDBC_Connection.connect();
        String showColumnsQuery = "SHOW COLUMNS FROM " + table;
        StringBuilder sb = new StringBuilder("UPDATE " + table + " SET ");

        try {
            String primaryKey = null;
            Statement statement = connection.createStatement();
            ResultSet result = statement.executeQuery(showColumnsQuery);
            ResultSetMetaData metaData = result.getMetaData();
            int columnCount = metaData.getColumnCount();

            int index = 1;
            while (result.next()) {
                if (index == 1) {
                    primaryKey = result.getString(1);
                } else {
                    String columnName = result.getString(1);
                    String columnType = metaData.getColumnTypeName(index);
                    System.out.println("Insert data to " + columnName + "(" + columnType + ")");
                    String newValue = scanner.nextLine();

                    // appends para los stringBuilders del principio del método para ir construyendo la consulta.
                    // si es la última columna, no añade una ',' al final.
                    if (index == columnCount) {
                        sb.append(table + "." + columnName + " = '" + newValue + "'");
                    } else {
                        sb.append(table + "." + columnName + " = '" + newValue + "', ");
                    }
                }

                index++;
            }
            result.close();

            sb.append(" WHERE " + primaryKey + " = " + id + ";");
            System.out.println(sb);

            Statement updateStatement = connection.createStatement();
            int affectedRows = updateStatement.executeUpdate(sb.toString());
            System.out.println("Row updated successfully (" + affectedRows + ")");

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } finally {
            connection.close();
        }
    }

    public static void deleteRow(String table, String primaryKey, String id) throws SQLException {
        Connection connection = JDBC_Connection.connect();
        Scanner scanner = new Scanner(System.in);
        System.out.println("Are you sure you want to delete this row? (y/n)");
        String option = scanner.next();

        int counter = 0;
        while (!option.equals("y")) {
            System.out.println("Option not valid, try again");
            option = scanner.next();
            counter++;

            if (counter == 3) {
                System.out.println("Too many attempts, returning to main menu...");
                showTables();
            }
        }

        String query = "DELETE FROM " + table + " WHERE " + primaryKey + " = " + id;
        Statement statement = connection.createStatement();
        int numberColumnsDeleted = statement.executeUpdate(query);
        System.out.println("Row deleted succesfully (" + numberColumnsDeleted + ")");
        connection.close();
    }

    public static void navigateTableData(String table) throws SQLException {
        Connection connection = JDBC_Connection.connect();
        Statement statement = connection.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        ResultSet result = statement.executeQuery("SELECT * FROM " + table);

        try {
            ResultSetMetaData metaData = result.getMetaData();
            int columnCount = metaData.getColumnCount();

            System.out.println("Table: " + table);
            System.out.println("====================");

            while (true) {
                System.out.println("Navigation options:");
                System.out.println("1. Next row");
                System.out.println("2. Previous row");
                System.out.println("3. Last row");
                System.out.println("4. After last row");
                System.out.println("5. Get current row");
                System.out.println("6. Exit");
                Scanner scanner = new Scanner(System.in);
                int choice = scanner.nextInt();

                switch (choice) {
                    case 1 -> {
                        if (result.next()) {
                            displayCurrentRow(result, columnCount);
                        } else {
                            System.out.println("No more rows.");
                            result.afterLast();
                        }
                    }
                    case 2 -> {
                        if (result.previous()) {
                            displayCurrentRow(result, columnCount);
                        } else {
                            System.out.println("No previous rows.");
                            result.beforeFirst();
                        }
                    }
                    case 3 -> {
                        if (result.last()) {
                            displayCurrentRow(result, columnCount);
                        }
                    }
                    case 4 -> {
                        result.afterLast();
                        System.out.println("Pointer moved after last row.");
                    }
                    case 5 -> {
                        int currentRow = result.getRow();
                        if (currentRow == 0) {
                            System.out.println("Cursor is not on a valid row.");
                        } else {
                            System.out.println("Current row: " + currentRow);
                            displayCurrentRow(result, columnCount);
                        }
                    }
                    case 6 -> {
                        return;
                    }
                    default -> System.out.println("Invalid option, try again.");
                }
            }
        } finally {
            result.close();
            connection.close();
        }
    }

    private static void displayCurrentRow(ResultSet result, int columnCount) throws SQLException {
        ResultSetMetaData metaData = result.getMetaData();

        for (int i = 1; i <= columnCount; i++) {
            String columnName = metaData.getColumnName(i);
            System.out.printf("%-32s", columnName);
        }

        System.out.println();

        for (int i = 1; i <= columnCount; i++) {
            String columnValue = result.getString(i);
            if (result.wasNull()) {
                System.out.printf("%-32s", "NULL");
            } else {
                System.out.printf("%-32s", columnValue);
            }
        }
        System.out.println();
    }


    public static boolean searchId(String table, String id) throws SQLException {
        Connection connection = JDBC_Connection.connect();
        Statement statement = connection.createStatement();

        ResultSet result = statement.executeQuery("SELECT * FROM " + table);
        while (result.next()) {
            if (result.getString(1).equals(id)) {
                connection.close();
                return true;
            }
        }
        connection.close();
        return false;
    }

}




