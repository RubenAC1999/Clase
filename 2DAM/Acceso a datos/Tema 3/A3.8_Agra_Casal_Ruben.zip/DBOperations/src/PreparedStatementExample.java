import java.sql.*;
import java.util.Scanner;

public class PreparedStatementExample {
    public static void main(String[] args) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Indique que tabla desea consultar: ");
        System.out.println("1. Parking");
        System.out.println("2. Garajes");
        System.out.println("3. Usuarios");
        System.out.println("4. Salir");
        int option = scanner.nextInt();

        switch (option) {
            case 1 -> preparedStatementParking();
            case 2 -> preparedStatementGarajes();
            case 3 -> preparedStatementUsuario();
            case 4 -> System.out.println("Cerrando programa...");
        }
    }

    public static void preparedStatementParking() throws SQLException {
        Connection connection = JDBC_Connection.connect();
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Filtrar por nombre");
        System.out.println("2. Filtrar por ciudad.");
        int option = scanner.nextInt();
        scanner.nextLine();
        PreparedStatement preparedStatement = null;

        if (option == 1) {
            System.out.println("Indique el nombre: ");
            String nombre = scanner.nextLine();

            String query = "SELECT * FROM parkings WHERE nombre = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nombre);
            System.out.println(query);

        } else if (option == 2) {
            System.out.println("Indique la ciudad: ");
            String ciudad = scanner.nextLine();

            String query = "SELECT * FROM parkings WHERE ciudad = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, ciudad);
            System.out.println(query);
        }

        ResultSet result = preparedStatement.executeQuery();
        ResultSetMetaData metaData = result.getMetaData();

        int columnCount = metaData.getColumnCount();
        for (int i = 1; i <= columnCount; i++) {
            System.out.printf("%-25s", metaData.getColumnName(i));
        }
        System.out.println();
        while (result.next()) {
            for (int i = 1; i <= columnCount; i++) {
                System.out.printf("%-25s", result.getString(i));
            }
        }

        result.close();
        connection.close();
    }


    public static void preparedStatementGarajes() throws SQLException {
        Connection connection = JDBC_Connection.connect();
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Filtrar por precio");
        System.out.println("2. Filtrar por disponibilidad");
        int option = scanner.nextInt();
        scanner.nextLine();
        PreparedStatement preparedStatement = null;

        if (option == 1) {
            System.out.println("Indique el precio: ");
            String precio = scanner.nextLine();

            String query = "SELECT * FROM garajes WHERE precio = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, precio);
            System.out.println(query);

        } else if (option == 2) {
            System.out.println("Indique la disponibilidad (s/n)");
            String disponibilidad = scanner.nextLine();

            if (disponibilidad.equals("s")) {
                disponibilidad = "1";
            } else if (disponibilidad.equals("n")) {
                disponibilidad = "0";
            }

            String query = "SELECT * FROM garajes WHERE disponibleAlquiler = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, disponibilidad);
            System.out.println(query);
        }

        ResultSet result = preparedStatement.executeQuery();
        ResultSetMetaData metaData = result.getMetaData();

        int columnCount = metaData.getColumnCount();
        for (int i = 1; i <= columnCount; i++) {
            System.out.printf("%-25s", metaData.getColumnName(i));
        }


        System.out.println();

        while (result.next()) {
            for (int i = 1; i <= columnCount; i++) {
                System.out.printf("%-25s", result.getString(i));
            }
            System.out.println();
        }

        result.close();
        connection.close();
    }

    public static void preparedStatementUsuario() throws SQLException {
        Connection connection = JDBC_Connection.connect();
        Scanner scanner = new Scanner(System.in);
        System.out.println("1. Filtrar por nombre");
        System.out.println("2. Filtrar por teléfono");
        int option = scanner.nextInt();
        scanner.nextLine();
        PreparedStatement preparedStatement = null;

        if (option == 1) {
            System.out.println("Indique el nombre: ");
            String nombre = scanner.nextLine();

            String query = "SELECT * FROM usuario WHERE nombre = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, nombre);
            System.out.println(query);
        } else if (option == 2) {
            System.out.println("Indique el teléfono");
            String telefono = scanner.nextLine();

            String query = "SELECT * FROM usuario WHERE telefono = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, telefono);
            System.out.println(query);
        }

        ResultSet result = preparedStatement.executeQuery();
        ResultSetMetaData metaData = result.getMetaData();

        int columnCount = metaData.getColumnCount();
        for (int i = 1; i <= columnCount; i++) {
            System.out.printf("%-25s", metaData.getColumnName(i));
        }


        System.out.println();

        while (result.next()) {
            for (int i = 1; i <= columnCount; i++) {
                System.out.printf("%-25s", result.getString(i));
            }
            System.out.println();
        }

        result.close();
        connection.close();
    }
}
