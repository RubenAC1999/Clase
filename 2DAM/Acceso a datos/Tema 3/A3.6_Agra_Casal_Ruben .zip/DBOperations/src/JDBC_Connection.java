import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class JDBC_Connection {
    public static void muestraErrorSQL(SQLException e) {
      System.err.println("SQL Error mensaje: " + e.getMessage());

      System.err.println("SQL Estado: " + e.getSQLState());

      System.err.println("SQL código específico: " + e.getErrorCode());
    }

    public static Connection connect() {
        String basedatos = "gestion_plazas";
        String host = "localhost";
        String port = "3306";
        String parAdic = "?useUnicode=true&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
        String urlConnection = "jdbc:mysql://" + host + ":" + port + "/" + basedatos + parAdic;
        String user = "usuarioGlobal";
        String pwd = "abc123.";

        try {
            return DriverManager.getConnection(urlConnection, user, pwd);
        } catch (SQLException e) {
            muestraErrorSQL (e);
        }catch (Exception e) {
            e.printStackTrace(System.err);
        }
        return null;
    }

}