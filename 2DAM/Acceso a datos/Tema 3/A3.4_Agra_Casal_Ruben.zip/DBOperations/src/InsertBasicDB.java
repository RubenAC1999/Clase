import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Scanner;

public class InsertBasicDB {
    public static void main(String[] args) throws SQLException {
        JDBC_Connection.connect();
        switch(initialize()) {
            case 1:
            System.out.println("Function not created.");
                break;
            case 2:
                showTables();
                break;
            case 0:
                System.out.println("Closing connection");
        }
    }


    public static int initialize() {
        Scanner scanner = new Scanner(System.in);


        System.out.println("DB Menu");
        System.out.println("==============================");
        System.out.println("1. Create new Table");
        System.out.println("2. Operate with tables");
        System.out.println("0. Close connection");
        int option = scanner.nextInt();
        return option;
    }



    public static void showTables() throws SQLException {
        Scanner scanner = new Scanner (System.in);
        Connection connection = JDBC_Connection.connect();
        Statement statement = connection.createStatement();
        ResultSet result = statement.executeQuery("SHOW TABLES;");
        StringBuilder sb = new StringBuilder("\nTables in the DB:\n");
        ArrayList<String> tables = new ArrayList<>();
        while (result.next()) {
            String columnName = result.getString(1);
            sb.append(columnName);
            sb.append("\n");
            tables.add(columnName);
        }

        boolean tableFounded = false;
        do {
            System.out.println(sb.toString());
            System.out.println("Indicate the table: ");
            String tableOption = scanner.nextLine();



            for (String table : tables) {
                if(tableOption.equals(table)) {
                    System.out.println("Table founded");
                    String tableSelected = tableOption;
                    tableFounded = true;
                    operationsMenu(tableSelected);
                    break;
                }

            }

            if (!tableFounded) {
                System.out.println("Table not founded, try again.");
            }
        } while (!tableFounded);



        result.close();
        statement.close();
        connection.close();
    }

    public static void operationsMenu(String table) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Select an operation");
        System.out.println("=====================");
        System.out.println("1. Insert");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                insertData(table);
                break;

        }
    }

    public static void insertData(String table) throws SQLException {
        Scanner scanner = new Scanner(System.in);
        Connection connection = JDBC_Connection.connect();
        Statement statement = connection.createStatement();
        String query = "SHOW COLUMNS FROM " + table;
        ResultSet result = statement.executeQuery(query);
        StringBuilder insertQueryColumns = new StringBuilder("INSERT INTO " + table + "(");
        StringBuilder insertQueryValues = new StringBuilder(") VALUES (");
        int numberOfColumns = 0;

        while (result.next()) {
            numberOfColumns++;
        }

        result.beforeFirst();

        int currentIndex = 0;
        while (result.next()) {
            System.out.println("Insert data to " + result.getString(1));
            String columnName = result.getString(1);
            String value = scanner.nextLine();

            if (currentIndex < numberOfColumns - 1) {
                insertQueryColumns.append(columnName + ",");
                insertQueryValues.append("'" + value + "',");
            } else {
                insertQueryColumns.append(columnName);
                insertQueryValues.append("'" + value +"'");
            }

            currentIndex++;
        }
        String insertQuery = insertQueryColumns.append(insertQueryValues + ");").toString();
        System.out.println(insertQuery);
        Statement insertStatement = connection.createStatement();
        int insertResult = insertStatement.executeUpdate(insertQuery);
        System.out.println("Numero de filas creadas: " + insertResult);
        result.close();
        statement.close();
        insertStatement.close();
        connection.close();
    }

}
