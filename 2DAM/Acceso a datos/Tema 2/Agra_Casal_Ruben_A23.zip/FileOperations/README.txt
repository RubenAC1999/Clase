---------------------------------
|  EDITOR DE FICHEROS EN JAVA   |
---------------------------------

El programa permite hacer diversas operaciones con ficheros, por ejemplo listar directorios, mover, copiar, etc. Para algunos métodos se ha empleado la librería Apache Commons IO.


FUNCIONALIDADES
-----------------------------
Para cada uno de estos métodos se preguntará al usuario una ruta.

1. Listar directorios ya sea de forma simplificada o de forma detallada (tamaño del archivo, permisos, última fecha de modificación).
2. Crear carpetas.
3. Copiar archivos.
4. Mover archivos. 

Los métodos 3 y 4 pedirá al usuario una ruta tanto del archivo a mover o copiar como de la ruta del archivo de destino. (Emplean la librería FileUtils).


DEPENDENCIAS
-------------------------------
Apache Commons IO: Librería para maneras extra de manipulación de archivos.
Enlace: https://commons.apache.org/io/download_io.cgi


EJEMPLO DE USO
-------------------------------
Al ejecutar el programa, se desplegará el menú con las posibles opciones. Deberemos poner por consola el número de la opción que deseamos emplear. Dependiendo de la opción pedirá una o dos rutas del archivo.

Para ejecutar el programa debemos hacer: 
1. Compilación: javac -cp "ruta\librería.jar" src\Main.java
2. Ejecución: java -cp "ruta\librería.jar" src\Main.java

