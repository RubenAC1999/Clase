import org.apache.commons.io.FileUtils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        int option;
        do {
            option = initialize();
            switch (option) {
                case 1:
                    listFilesSimplified();
                    break;
                case 2:
                    listFilesDetailed();
                    break;
                case 3:
                    createFolder();
                    break;
                case 4:
                    copyFile();
                    break;
                case 5:
                    moveFile();
                    break;
                case 6:
                    writeFile();
                    break;
                case 0:
                    System.out.println("Cerrando aplicación...");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida, inténtelo de nuevo.");
            }
        } while (option != 0);
    }

    public static int initialize() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("=======================");
        System.out.println("Editor de ficheros");
        System.out.println("=======================");
        System.out.println("Elija una opción: ");
        System.out.println("1. Listar archivos de forma simplificada.");
        System.out.println("2. Listar archivos de forma detallada.");
        System.out.println("3. Crear carpeta.");
        System.out.println("4. Copiar archivo.");
        System.out.println("5. Mover archivo.");
        System.out.println("6. Escribir en un archivo.");
        System.out.println("0. Salir");
        return scanner.nextInt();
    }

    public static File getFileFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduzca la ruta del archivo: ");
        String filePath = scanner.next();
        return new File(filePath);
    }

    public static String getInformation(File file) {
        StringBuilder information = new StringBuilder();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        long date = file.lastModified();

        // Dependiendo de si el elemento es un archivo o un directorio, la información que se mostrará será diferente.
        if (file.isFile()) {
            information.append("(_) ")
                    .append(file.getName())
                    .append(" [")
                    .append(file.length())
                    .append(" bytes, ");
        } else if (file.isDirectory()) {
            information.append("(/) ")
                    .append(file.getName())
                    .append(" [");
        }
        information.append(file.canRead() ? "r" : "-")
                .append(file.canExecute() ? "x" : "-")
                .append(file.canWrite() ? "w " : "- ")
                .append(formatter.format(date))
                .append("]");

        return information.toString();
    }


    public static void listFilesSimplified() {
        StringBuilder sb = new StringBuilder();
        File fileFound = getFileFromUser();
        if (fileFound.isDirectory()) {
            System.out.println(fileFound.getName() + " es un directorio.");
            for (String fileStr : fileFound.list()) {
                if (fileStr == null) {
                    System.out.println("El directorio está vacío.");
                    break;
                }
                File file = new File(fileStr);
                sb.append(file.getName()).append("\n");
            }
            System.out.println(sb.toString());
        } else if (fileFound.isFile()) {
            System.out.println(fileFound.getName() + " es un archivo.");
        }
    }

    public static void listFilesDetailed() {
        File fileFound = getFileFromUser();
        if (fileFound.isDirectory()) {
            System.out.println(fileFound.getName() + " es un directorio.");
            for (String fileStr : fileFound.list()) {
                File file = new File(fileStr);
                System.out.println(getInformation(file));
            }
        } else if (fileFound.isFile()) {
            System.out.println(fileFound.getName() + " es un archivo");
        }
    }

    public static void createFolder() {
        File fileFound = getFileFromUser();
        if (fileFound.mkdir()) {
            System.out.println("Carpeta creada correctamente.");
        } else {
            System.out.println("Error no se pudo crear la carpeta.");
        }
    }

    // Emplea la librería FileUtils
    public static void copyFile() {
        File srcFile = getFileFromUser();
        System.out.println("Mover a: ");
        File destFile = getFileFromUser();

        if (srcFile.exists()) {
            try {
                FileUtils.copyFileToDirectory(srcFile, destFile);
            } catch (IOException e) {
                System.out.println("Error al copiar el archivo \n" + e.getMessage());
            }
        }
    }

    // Emplea la librería FileUtils
    public static void moveFile() {
        File srcFile = getFileFromUser();
        System.out.println("Mover a: ");
        File destFile = getFileFromUser();
            try {
                FileUtils.moveFile(srcFile, destFile);
            } catch (IOException e) {
                System.out.println("Error al mover el archivo \n" + e.getMessage());
            }
        }

        public static void writeFile() {
            try {
                File fileSrc = getFileFromUser();
                FileWriter writer = new FileWriter(fileSrc, true);
                BufferedWriter buffWriter = new BufferedWriter(writer);
                if (fileSrc.exists()) {
                    Scanner scanner = new Scanner(System.in);
                    System.out.println("Coloque lo que desea escribir: ");
                    String content = scanner.nextLine();
                    buffWriter.write(content);
                    buffWriter.close();
                    writer.close();
                    System.out.println("Contenido agregado correctamente.");
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
    }


