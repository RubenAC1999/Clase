import org.apache.commons.io.FileUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.*;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        initialize();
    }


    public static void initialize() {
        int option;
        do {
            Scanner scanner = new Scanner(System.in);
            System.out.println("=======================");
            System.out.println("Editor de ficheros");
            System.out.println("=======================");
            System.out.println("Elija una opción: ");
            System.out.println("1. Listar archivos de forma simplificada.");
            System.out.println("2. Listar archivos de forma detallada.");
            System.out.println("3. Crear carpeta.");
            System.out.println("4. Copiar archivo.");
            System.out.println("5. Mover archivo.");
            System.out.println("6. Escribir en un archivo.");
            System.out.println("7. Leer un archivo.");
            System.out.println("0. Salir");
            option = scanner.nextInt();

            switch (option) {
                case 1:
                    listFilesSimplified();
                    break;
                case 2:
                    listFilesDetailed();
                    break;
                case 3:
                    createFolder();
                    break;
                case 4:
                    copyFile();
                    break;
                case 5:
                    moveFile();
                    break;
                case 6:
                    writeFileSubmenu();
                    break;
                case 7:
                    readFileSubmenu();
                    break;
                case 0:
                    System.out.println("Cerrando aplicación...");
                    System.exit(0);
                default:
                    System.out.println("Opción no válida, inténtelo de nuevo.");
            }

            doAnotherOperation();

        } while (option != 0);
    }

    public static void writeFileSubmenu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Escribir en un archivo de texto plano.");
        System.out.println("2. Añadir un piso nuevo en la base de datos.");
        System.out.println("3. Añadir un inquilino en la base de datos.");
        System.out.println("4. Añadir un propietario en la base de datos.");
        System.out.println("5. Atrás.");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                writeFile();
                break;
            case 2:
                addPisoToXML();
                break;
            case 3:
                addInquilinoToXML();
                break;
            case 4:
                addPropietarioToXml();
                break;
            case 5:
                initialize();
                break;
        }
    }

    public static void readFileSubmenu() {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Leer un archivo específico.");
        System.out.println("2. Leer pisos.xml");
        System.out.println("3. Leer inquilinos.xml");
        System.out.println("4. Leer propietarios.xml");
        System.out.println("5. Atrás.");
        int option = scanner.nextInt();

        switch (option) {
            case 1:
                readFile();
                break;
            case 2:
                break;
            case 3:
                break;
            case 4:
                break;
            case 5:
                initialize();

        }
    }

    public static File getFileFromUser() {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduzca la ruta del archivo: ");
        String filePath = scanner.next();
        return new File(filePath);
    }

    public static String getFileInformation(File file) {
        StringBuilder information = new StringBuilder();
        DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        long date = file.lastModified();

        // Dependiendo de si el elemento es un archivo o un directorio, la información que se mostrará será diferente.
        if (file.isFile()) {
            information.append("(_) ")
                    .append(file.getName())
                    .append(" [")
                    .append(file.length())
                    .append(" bytes, ");
        } else if (file.isDirectory()) {
            information.append("(/) ")
                    .append(file.getName())
                    .append(" [");
        }
        information.append(file.canRead() ? "r" : "-")
                .append(file.canExecute() ? "x" : "-")
                .append(file.canWrite() ? "w " : "- ")
                .append(formatter.format(date))
                .append("]");

        return information.toString();
    }

    public static void listFilesSimplified() {
        StringBuilder sb = new StringBuilder();
        File fileFound = getFileFromUser();
        if (fileFound.isDirectory()) {
            System.out.println(fileFound.getName() + " es un directorio.");
            for (String fileStr : fileFound.list()) {
                if (fileStr == null) {
                    System.out.println("El directorio está vacío.");
                    break;
                }
                File file = new File(fileStr);
                sb.append(file.getName()).append("\n");
            }
            System.out.println(sb.toString());
        } else if (fileFound.isFile()) {
            System.out.println(fileFound.getName() + " es un archivo.");
        }

    }

    public static void listFilesDetailed() {
        File fileFound = getFileFromUser();
        if (fileFound.isDirectory()) {
            System.out.println(fileFound.getName() + " es un directorio.");
            for (String fileStr : fileFound.list()) {
                File file = new File(fileStr);
                System.out.println(getFileInformation(file));
            }
        } else if (fileFound.isFile()) {
            System.out.println(fileFound.getName() + " es un archivo");
        }
    }

    public static void createFolder() {
        File fileFound = getFileFromUser();
        if (fileFound.mkdir()) {
            System.out.println("Carpeta creada correctamente.");
        } else {
            System.out.println("Error no se pudo crear la carpeta.");
        }
    }

    // Emplea la librería FileUtils
    public static void copyFile() {
        File srcFile = getFileFromUser();
        System.out.println("Mover a: ");
        File destFile = getFileFromUser();

        if (srcFile.exists()) {
            try {
                FileUtils.copyFileToDirectory(srcFile, destFile);
            } catch (IOException e) {
                System.out.println("Error al copiar el archivo \n" + e.getMessage());
            }
        }
    }

    // Emplea la librería FileUtils
    public static void moveFile() {
        File srcFile = getFileFromUser();
        System.out.println("Mover a: ");
        File destFile = getFileFromUser();
        try {
            FileUtils.moveFile(srcFile, destFile);
        } catch (IOException e) {
            System.out.println("Error al mover el archivo \n" + e.getMessage());
        }
    }

    public static void writeFile() {
        try {
            File fileSrc = getFileFromUser();
            FileWriter writer = new FileWriter(fileSrc, true);
            BufferedWriter buffWriter = new BufferedWriter(writer);
            if (fileSrc.exists()) {
                Scanner scanner = new Scanner(System.in);
                System.out.println("Coloque lo que desea escribir: ");
                String content = scanner.nextLine();
                buffWriter.write(content);
                buffWriter.close();
                writer.close();
                System.out.println("Contenido agregado correctamente.");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    public static void readFile() {
        try {
            File fileSrc = getFileFromUser();
            FileReader reader = new FileReader(fileSrc);
            BufferedReader buffer = new BufferedReader(reader);
            Scanner scanner = new Scanner(buffer);

            while (scanner.hasNext()) {
                String data = scanner.nextLine();
                System.out.println(data);
            }
            scanner.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public static Document getDocument(String route) throws ParserConfigurationException, IOException, SAXException {
        File file = new File(route);
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        DocumentBuilder builder = factory.newDocumentBuilder();
        Document doc;
        doc = builder.parse(file);
        doc.getDocumentElement().normalize();

        return doc;
    }

    public static void addPisoToXML() {

        // Recogemos los datos
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese la dirección: ");
        String direccion = scanner.nextLine();

        System.out.println("Ingrese la ciudad: ");
        String ciudad = scanner.nextLine();

        System.out.println("Ingrese la superficie: ");
        int superficie = scanner.nextInt();

        System.out.println("Ingrese el nº de habitaciones: ");
        int numHabitaciones = scanner.nextInt();

        System.out.println("Ingrese el precio del alquiler: ");
        int precioAlquiler = scanner.nextInt();

        // Accedemos al DOM para insertar los datos.
        try {
            Document doc = getDocument(Databases.PISOS.getRoute());
            var pisos = doc.getElementsByTagName("Piso");
            System.out.println("Nº de pisos registrados actualmente: " + pisos.getLength());
            Element newPiso = doc.createElement("Piso");
            Element root = doc.getDocumentElement();

            Element idElement = doc.createElement("ID");
            newPiso.appendChild(doc.createTextNode("\n\t\t"));
            int id = pisos.getLength() + 1;
            idElement.appendChild(doc.createTextNode(String.valueOf(id)));
            newPiso.appendChild(idElement);
            root.appendChild(doc.createTextNode("\n\t"));

            Element direccionElement = doc.createElement("Direccion");
            newPiso.appendChild(doc.createTextNode("\n\t\t"));
            direccionElement.appendChild(doc.createTextNode(direccion));
            newPiso.appendChild(direccionElement);

            Element ciudadElement = doc.createElement("Ciudad");
            newPiso.appendChild(doc.createTextNode("\n\t\t"));
            ciudadElement.appendChild(doc.createTextNode(ciudad));
            newPiso.appendChild(ciudadElement);

            Element superficieElement = doc.createElement("Superficie");
            newPiso.appendChild(doc.createTextNode("\n\t\t"));
            superficieElement.appendChild(doc.createTextNode(String.valueOf(superficie)));
            newPiso.appendChild(superficieElement);

            Element numHabitacionesElement = doc.createElement("NumeroHabitaciones");
            newPiso.appendChild(doc.createTextNode("\n\t\t"));
            numHabitacionesElement.appendChild(doc.createTextNode(String.valueOf(numHabitaciones)));
            newPiso.appendChild(numHabitacionesElement);

            Element precioAlquilerElement = doc.createElement("PrecioAlquiler");
            newPiso.appendChild(doc.createTextNode("\n\t\t"));
            precioAlquilerElement.appendChild(doc.createTextNode(String.valueOf(precioAlquiler)));
            newPiso.appendChild(precioAlquilerElement);

            newPiso.appendChild(doc.createTextNode("\n\t"));
            doc.getDocumentElement().appendChild(newPiso);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();


            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(new File(Databases.PISOS.getRoute()));
            transformer.transform(source, result);

            System.out.println("Piso agregado correctamente al archivo XML.");

        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    public static void addInquilinoToXML() {
        // Pedimos los datos al usuario
        Scanner scanner = new Scanner(System.in);
        System.out.println("Ingrese el nombre: ");
        String nombre = scanner.nextLine();

        System.out.println("Ingrese el nº de teléfono: ");
        String telefono = scanner.nextLine();

        System.out.println("Ingrese el correo electrónico: ");
        String correoElectronico = scanner.nextLine();

        System.out.println("Ingrese el id del piso alquilado: ");
        int idPiso = scanner.nextInt();

        System.out.println("Ingrese la duración del contrato: ");
        int duracionContrato = scanner.nextInt();

        // Accedemos al DOM para insertar los datos.
        try {
            Document doc = getDocument(Databases.INQUILINOS.getRoute());
            var inquilinos = doc.getElementsByTagName("Inquilino");
            System.out.println("Nº de inquilinos registrados actualmente: " + inquilinos.getLength());
            Element root = doc.getDocumentElement();
            Element newInquilino = doc.createElement("Inquilino");
            root.appendChild(doc.createTextNode("\n\t"));

            int inquilinoId = inquilinos.getLength() + 1;
            Element inquilinoIdElement = doc.createElement("ID");
            newInquilino.appendChild(doc.createTextNode("\n\t\t"));
            inquilinoIdElement.appendChild(doc.createTextNode(String.valueOf(inquilinoId)));
            newInquilino.appendChild(inquilinoIdElement);

            Element nombreElement = doc.createElement("Nombre");
            newInquilino.appendChild(doc.createTextNode("\n\t\t"));
            nombreElement.appendChild(doc.createTextNode(nombre));
            newInquilino.appendChild(nombreElement);

            Element telefonoElement = doc.createElement("Telefono");
            newInquilino.appendChild(doc.createTextNode("\n\t\t"));
            telefonoElement.appendChild(doc.createTextNode(telefono));
            newInquilino.appendChild(telefonoElement);

            Element correoElement = doc.createElement("Correo");
            newInquilino.appendChild(doc.createTextNode("\n\t\t"));
            correoElement.appendChild(doc.createTextNode(correoElectronico));
            newInquilino.appendChild(correoElement);

            Element pisoIdElement = doc.createElement("PisoAlquiladoID");
            newInquilino.appendChild(doc.createTextNode("\n\t\t"));
            pisoIdElement.appendChild(doc.createTextNode(String.valueOf(idPiso)));
            newInquilino.appendChild(pisoIdElement);

            Element duracionContratoElement = doc.createElement("DuracionContrato");
            newInquilino.appendChild(doc.createTextNode("\n\t\t"));
            duracionContratoElement.appendChild(doc.createTextNode(String.valueOf(duracionContrato)));
            newInquilino.appendChild(duracionContratoElement);

            newInquilino.appendChild(doc.createTextNode("\n\t"));
            doc.getDocumentElement().appendChild(newInquilino);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(Databases.INQUILINOS.getRoute());
            transformer.transform(source, result);

            System.out.println("Inquilino agregado correctamente al XML.");


        } catch (RuntimeException | ParserConfigurationException | SAXException | IOException |
                 TransformerException e) {
            e.printStackTrace();
        }
    }

    public static void addPropietarioToXml() {
        // Pedimos los datos al usuario.
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduzca el nombre: ");
        String nombre = scanner.nextLine();

        System.out.println("Introduzca el teléfono: ");
        String telefono = scanner.nextLine();

        System.out.println("Introduzca un correo electrónico: ");
        String correoElectronico = scanner.nextLine();

        System.out.println("Introduzca el número de propiedades: ");
        int numPropiedades = scanner.nextInt();


        // Accedemos al DOM para insertar los datos.
        try {
            Document doc = getDocument(Databases.PROPIETARIOS.getRoute());
            var propietarios = doc.getElementsByTagName("Propietario");
            System.out.println("Nº de propietarios registrados actualmente: " + propietarios.getLength());
            Element root = doc.getDocumentElement();
            Element newPropietario = doc.createElement("Propietario");
            root.appendChild(doc.createTextNode("\n\t"));

            int propietarioId = propietarios.getLength() + 1;
            Element propietarioIdElement = doc.createElement("ID");
            newPropietario.appendChild(doc.createTextNode("\n\t\t"));
            propietarioIdElement.appendChild(doc.createTextNode(String.valueOf(propietarioId)));
            newPropietario.appendChild(propietarioIdElement);

            Element nombreElement = doc.createElement("Nombre");
            newPropietario.appendChild(doc.createTextNode("\n\t\t"));
            nombreElement.appendChild(doc.createTextNode(nombre));
            newPropietario.appendChild(nombreElement);

            Element telefonoElement = doc.createElement("Telefono");
            newPropietario.appendChild(doc.createTextNode("\n\t\t"));
            telefonoElement.appendChild(doc.createTextNode(telefono));
            newPropietario.appendChild(telefonoElement);

            Element correoElement = doc.createElement("Correo");
            newPropietario.appendChild(doc.createTextNode("\n\t\t"));
            correoElement.appendChild(doc.createTextNode(correoElectronico));
            newPropietario.appendChild(correoElement);

            Element propiedadesElement = doc.createElement("Propiedades");
            newPropietario.appendChild(doc.createTextNode("\n\t\t"));
            propiedadesElement.appendChild(doc.createTextNode(String.valueOf(numPropiedades)));
            newPropietario.appendChild(propiedadesElement);

            newPropietario.appendChild(doc.createTextNode("\n\t"));
            doc.getDocumentElement().appendChild(newPropietario);

            TransformerFactory transformerFactory = TransformerFactory.newInstance();
            Transformer transformer = transformerFactory.newTransformer();

            DOMSource source = new DOMSource(doc);
            StreamResult result = new StreamResult(Databases.INQUILINOS.getRoute());
            transformer.transform(source, result);

            System.out.println("Propietario agregado correctamente al XML.");


        } catch (ParserConfigurationException | SAXException | IOException | TransformerException e) {
            throw new RuntimeException(e);
        }

    }

    public static void showPisosXML() throws ParserConfigurationException, IOException, SAXException {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Cuantas habitaciones desea: ");
        String rooms = scanner.next();
        Document doc = getDocument(Databases.PISOS.getRoute());
        NodeList numberOfRoomsNodeList = doc.getElementsByTagName("NumeroHabitaciones");
        for (int i = 0; i < numberOfRoomsNodeList.getLength(); i++) {
            Node numberOfRoomsNode = numberOfRoomsNodeList.item(i);
            String nodeValue = numberOfRoomsNode.getTextContent();

            if (Integer.parseInt(rooms) < Integer.parseInt(nodeValue)) {
                Node flatNode = numberOfRoomsNode.getParentNode();
                NodeList flatChildNodes = flatNode.getChildNodes();
                for (int j = 0; i < flatChildNodes.getLength(); i++) {
                    String elementContent = "<" + flatChildNodes.item(j).getNodeName() + ">"
                            + flatChildNodes.item(j).getTextContent()
                            + "<" + flatChildNodes.item(j).getNodeName() + ">";
                }
            }
        }

    }

    public static void doAnotherOperation() {
        Scanner scanner = new Scanner(System.in);
        String option = "";
        do {
            System.out.println("¿Desea hacer otra operación? (y/n)");
            option = scanner.nextLine();
            if (option.equalsIgnoreCase("y")) {
                break;
            } else if (option.equalsIgnoreCase("n")) {
                System.out.println("Cerrando programa...");
                System.exit(0);
            } else {
                System.out.println("Error, opción no válida.");
            }
        } while (!option.equalsIgnoreCase("n"));
    }
}


