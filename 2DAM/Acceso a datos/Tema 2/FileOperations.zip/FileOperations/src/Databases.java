public enum Databases {
    PISOS("BD/pisos.xml"),
    INQUILINOS("BD/inquilinos.xml"),
    PROPIETARIOS("BD/propietarios.xml");

    private final String route;

    Databases(String route) {
        this.route = route;
    }

    public String getRoute() {
        return this.route;
    }
}
