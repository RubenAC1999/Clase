public enum Databases {
    PISOS("BD/pisos.xml"),
    INQUILINOS("BD/inquilinos.xml"),
    PROPIETARIOS("BD/propietarios.xml"),
    JSON("BD/pisos_propietarios_inquilinos.json");

    private final String route;

    Databases(String route) {
        this.route = route;
    }

    public String getRoute() {
        return this.route;
    }
}
