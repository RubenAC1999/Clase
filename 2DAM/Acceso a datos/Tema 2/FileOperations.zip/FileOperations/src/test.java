import java.util.InputMismatchException;
import java.util.Scanner;

public class test {
    public static void main(String[] args) throws ExcepcionPersonalizada {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Introduzca un número");
        int numero = scanner.nextInt();
        if (numero < 0) {
            throw new ExcepcionPersonalizada("Error número debe ser mayor que 0.");
        }
    }
}
