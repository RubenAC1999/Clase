package model;

public class Piso {
    private int id;
    private String direccion;
    private String ciudad;
    private int superficie;
    private int numHabitaciones;
    private int precioAlquiler;

    public Piso(String direccion, String ciudad, int superficie, int numHabitaciones, int precioAlquiler) {
        this.direccion = direccion;
        this.ciudad = ciudad;
        this.superficie = superficie;
        this.numHabitaciones = numHabitaciones;
        this.precioAlquiler = precioAlquiler;
        this.id += id;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public String getCiudad() {
        return ciudad;
    }

    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }

    public int getSuperficie() {
        return superficie;
    }

    public void setSuperficie(int superficie) {
        this.superficie = superficie;
    }

    public int getNumHabitaciones() {
        return numHabitaciones;
    }

    public void setNumHabitaciones(int numHabitaciones) {
        this.numHabitaciones = numHabitaciones;
    }

    public int getPrecioAlquiler() {
        return precioAlquiler;
    }

    public void setPrecioAlquiler(int precioAlquiler) {
        this.precioAlquiler = precioAlquiler;
    }
}
