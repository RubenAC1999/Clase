import java.io.File;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Introduzca la ruta absoluta del archivo que desea comprobar: ");
        String rutaArchivo = scanner.next();

        File archivo = new File(rutaArchivo);
        System.out.println(archivo.exists());

        if (!archivo.exists()) {
            System.out.println(rutaArchivo + "\n Error, el archivo no existe.");
            System.exit(0);

        } else {
            System.out.println("Archivo encontrado.");

            if (archivo.isDirectory()) {
                System.out.println(archivo.getName() + " es un directorio. Contenidos: ");
                String[] listaContenidos = archivo.list();

                for (String contenido : listaContenidos) {
                    File contenidoFile = new File(contenido);
                    StringBuilder sb = new StringBuilder("");

                    if(contenidoFile.isDirectory()) {
                        sb.append("(/) " )
                                .append(contenidoFile.getName())
                                .append("[")
                                .append(verInformacion(contenidoFile))
                                .append("]\n");

                    } else if (contenidoFile.isFile()) {
                        sb.append("(_) ")
                                .append(contenidoFile.getName())
                                .append("[")
                                .append((contenidoFile.length()/0.125))
                                .append(" bytes,")
                                .append(verInformacion(contenidoFile))
                                .append("]\n");
                    }

                    System.out.print(sb.toString());

                }
            }
        }
    }

    public static String verInformacion(File archivo) {
        String informacion = "";
        DateFormat formateador = new SimpleDateFormat("dd/MM/yyyy hh:mm:ss");
        long fecha = archivo.lastModified();

        if(archivo.canRead()) {
            informacion += "r";
        } else {
            informacion += "-";
        }

        if(archivo.canExecute()) {
            informacion += "x";
        } else {
            informacion += "-";
        }

        if(archivo.canWrite()) {
            informacion += "w";
        } else {
            informacion += "-";
        }

        informacion += "," + formateador.format(fecha);

        return informacion;
    }
}
