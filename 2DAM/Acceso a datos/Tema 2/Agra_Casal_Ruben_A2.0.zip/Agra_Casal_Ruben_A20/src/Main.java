import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Main {
    public static void main(String[] args) throws ParseException {
        DateTimeFormatter formateador = DateTimeFormatter.ofPattern("dd/MM/yyyy hh:mm");
        String fecha = LocalDateTime.now().format(formateador);

        System.out.println("\t\t\tHola Mundo");
        System.out.println("===================================");
        System.out.println("Mi nombre es, Rubén Agra Casal.");
        System.out.println("Hoy es, " + fecha);
    }
}
