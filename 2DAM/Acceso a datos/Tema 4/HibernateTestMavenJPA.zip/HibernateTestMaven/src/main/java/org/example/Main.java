package org.example;

import entities.Sede;
import entities.Departamento;
import entities.Empleado;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.util.List;

public class SedeDAO {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("SedePU");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            // 1. Crear nueva sede
            Sede nuevaSede = new Sede();
            nuevaSede.setNombre("Sede Central");
            em.persist(nuevaSede);

            // 2. Crear dos departamentos y asignarlos a la sede
            Departamento depto1 = new Departamento();
            depto1.setNombre("Recursos Humanos");
            depto1.setSede(nuevaSede);
            em.persist(depto1);

            Departamento depto2 = new Departamento();
            depto2.setNombre("Tecnología");
            depto2.setSede(nuevaSede);
            em.persist(depto2);

            // 3. Crear dos empleados por cada departamento
            Empleado emp1 = new Empleado();
            emp1.setDni("12345678A");
            emp1.setNombre("Juan Pérez");
            emp1.setDepartamento(depto1);
            em.persist(emp1);

            Empleado emp2 = new Empleado();
            emp2.setDni("87654321B");
            emp2.setNombre("Ana Gómez");
            emp2.setDepartamento(depto1);
            em.persist(emp2);

            Empleado emp3 = new Empleado();
            emp3.setDni("11223344C");
            emp3.setNombre("Carlos López");
            emp3.setDepartamento(depto2);
            em.persist(emp3);

            Empleado emp4 = new Empleado();
            emp4.setDni("44332211D");
            emp4.setNombre("María Fernández");
            emp4.setDepartamento(depto2);
            em.persist(emp4);

            // 4. Asociar departamentos a la sede
            nuevaSede.setDepartamento(List.of(depto1, depto2));

            // Confirmar transacción
            em.getTransaction().commit();
            System.out.println("Datos insertados correctamente.");

        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
