package org.example;

// Mapeando con Hibernate XML
// Para proyectos antiguos, se utiliza para alejar el mapeo de una manera más externa del código

import entities.Departamento;
import entities.Empleado;
import entities.Sede;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class Main {
    public static void main(String[] args) {
        SessionFactory sessionFactory = HibernateUtil.getSessionFactory();

        Session session = sessionFactory.openSession();

        Transaction transaction = null;

        try {
            transaction = session.beginTransaction();

            Sede sede = new Sede();
            sede.setNombre("Sede principal");

            session.save(sede);

            Departamento depto1 = new Departamento();
            depto1.setNombre("Departamento de Ventas");
            depto1.setSede(sede);
            session.save(depto1);

            Departamento depto2 = new Departamento();
            depto2.setNombre("Departamento de Marketing");
            depto2.setSede(sede);
            session.save(depto2);

            Empleado emp1 = new Empleado();
            emp1.setDni("12345678A");
            emp1.setDepartamento(depto1);
            emp1.setNombre("Carlos Martínez");
            session.save(emp1);

            Empleado emp2 = new Empleado();
            emp2.setDni("12345677B");
            emp2.setDepartamento(depto1);
            emp2.setNombre("Andrés Iniesta");
            session.save(emp2);

            Empleado emp3 = new Empleado();
            emp3.setDni("12345676C");
            emp3.setDepartamento(depto2);
            emp3.setNombre("Lucía Carballido");
            session.save(emp3);

            Empleado emp4 = new Empleado();
            emp4.setDni("12345679D");
            emp4.setDepartamento(depto2);
            emp4.setNombre("Jorge García");
            session.save(emp4);

            transaction.commit();

        } catch (Exception e) {
            if (transaction != null) {
                transaction.rollback();
            }

            throw new RuntimeException(e);

        } finally {
            session.close();
        }
    }
}
