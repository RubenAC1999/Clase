package org.example;

import entities.*;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;

// Inserción de datos utilizando mapeo mediante anotaciones JPA
// Lo que más se usa actualmente, más rápido y sencillo.

public class Main {
    public static void main(String[] args) {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("dataPersistence");
        EntityManager em = emf.createEntityManager();

        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");

        try {
            em.getTransaction().begin();

            Sede nuevaSede = new Sede();
            nuevaSede.setNombre("Sede Central");
            em.persist(nuevaSede);

            Departamento depto1 = new Departamento();
            depto1.setNombre("Recursos Humanos");
            depto1.setSede(nuevaSede);
            em.persist(depto1);

            Empleado emp1 = new Empleado();
            emp1.setDni("12345678A");
            emp1.setNombre("Juan Pérez");
            emp1.setDepartamento(depto1);
            em.persist(emp1);

            Empleado emp2 = new Empleado();
            emp2.setDni("87654321B");
            emp2.setNombre("Ana Gómez");
            emp2.setDepartamento(depto1);
            em.persist(emp2);

            Empleado emp3 = new Empleado();
            emp3.setDni("11223344C");
            emp3.setNombre("Carlos López");
            emp3.setDepartamento(depto1);
            em.persist(emp3);

            Empleado emp4 = new Empleado();
            emp4.setDni("44332211D");
            emp4.setNombre("María Fernández");
            emp4.setDepartamento(depto1);
            em.persist(emp4);

            Empleado emp5 = new Empleado();
            emp5.setDni("21486473E");
            emp5.setNombre("Federico García");
            emp5.setDepartamento(depto1);
            em.persist(emp5);

            DatosProfEmpleado datosProf1 = new DatosProfEmpleado();
            datosProf1.setDni("12345678A");
            datosProf1.setCategoria("JR"); // Junior
            datosProf1.setEmpleado(emp1);
            datosProf1.setSueldoBrutoAnual(18000.00f);
            em.persist(datosProf1);

            DatosProfEmpleado datosProf2 = new DatosProfEmpleado();
            datosProf2.setDni("87654321B");
            datosProf2.setCategoria("SR"); // Senior
            datosProf2.setEmpleado(emp2);
            datosProf2.setSueldoBrutoAnual(24000.00f);
            em.persist(datosProf2);

            DatosProfEmpleado datosProf3 = new DatosProfEmpleado();
            datosProf3.setDni("11223344C");
            datosProf3.setCategoria("SR"); // Senior
            datosProf3.setEmpleado(emp3);
            datosProf3.setSueldoBrutoAnual(24000.00f);
            em.persist(datosProf3);

            DatosProfEmpleado datosProf4 = new DatosProfEmpleado();
            datosProf4.setDni("44332211D");
            datosProf4.setCategoria("JR"); // Junior
            datosProf4.setEmpleado(emp4);
            datosProf4.setSueldoBrutoAnual(18000.00f);
            em.persist(datosProf4);

            DatosProfEmpleado datosProf5 = new DatosProfEmpleado();
            datosProf5.setDni("21486473E");
            datosProf5.setCategoria("SR"); // Senior
            datosProf5.setEmpleado(emp5);
            datosProf5.setSueldoBrutoAnual(24000.00f);
            em.persist(datosProf5);

            Date fechaInicioProyecto1 = format.parse("2024-03-01");
            Date fechaFinProyecto1 = format.parse("2024-08-30");
            Date fechaInicioProyecto2 = format.parse("2024-01-15");
            Date fechaInicioProyecto3 = format.parse("2024-05-10");


            Proyecto p1 = new Proyecto();
            p1.setNombre("Sistema de gestión");
            p1.setfInicio(fechaInicioProyecto1);
            p1.setfFin(fechaFinProyecto1);
            em.persist(p1);

            Proyecto p2 = new Proyecto();
            p2.setNombre("Plataforma E-Commerc");
            p2.setfInicio(fechaInicioProyecto2);
            em.persist(p2);

            Proyecto p3 = new Proyecto();
            p3.setNombre("Aplicación móvil");
            p3.setfInicio(fechaInicioProyecto3);
            em.persist(p3);

            List<Empleado> empleados = em.createQuery("SELECT e FROM Empleado e", Empleado.class).getResultList();
            List<DatosProfEmpleado> datosProf = em.createQuery("SELECT d FROM DatosProfEmpleado d", DatosProfEmpleado.class).getResultList();
            List<Proyecto> proyectos = em.createQuery("SELECT p FROM Proyecto p", Proyecto.class).getResultList();

            empleados.forEach(System.out::println);
            datosProf.forEach(System.out::println);
            proyectos.forEach(System.out::println);


            nuevaSede.setDepartamento(List.of(depto1));

            em.getTransaction().commit();
            System.out.println("Datos insertados correctamente.");

        } catch (Exception e) {
            em.getTransaction().rollback();
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }
}
