package com.example.constraintlayouts

import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import com.example.constraintlayouts.screenActivities.Screen1Activity
import com.example.constraintlayouts.screenActivities.Screen2Activity
import com.example.constraintlayouts.screenActivities.Screen3Activity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val context = LocalContext.current
            Column {
                Button(
                    onClick = {
                        val serviceIntent1 = Intent(context, Screen1Activity::class.java)
                        startActivity(serviceIntent1)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Text(text = "Screen 1 Activity", color = Color.White)
                }
                Button(
                    onClick = {
                        val serviceIntent2 = Intent(context, Screen2Activity::class.java)
                        startActivity(serviceIntent2)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Text(text = "Screen 2 Activity", color = Color.White)
                }
                Button(
                    onClick = {
                        val serviceIntent3 = Intent(context, Screen3Activity::class.java)
                        startActivity(serviceIntent3)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color.Blue),
                    modifier = Modifier.padding(vertical = 8.dp)
                ) {
                    Text(text = "Screen 3 Activity", color = Color.White)
                }
            }

        }
    }
}
