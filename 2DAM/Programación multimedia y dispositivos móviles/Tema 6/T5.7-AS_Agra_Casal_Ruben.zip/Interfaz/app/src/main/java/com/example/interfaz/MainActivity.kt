package com.example.interfaz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ContextMenuApp()
        }
    }
}

@Composable
fun ContextMenuApp() {
    var selectedOption by remember { mutableStateOf("") } // Estado para la opción seleccionada
    var showSubMenu by remember { mutableStateOf(false) } // Estado para controlar la visibilidad del submenú

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFC7D0FF))
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Texto Superior
        Text(
            text = "Programación multimedia y dispositivos móviles",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 32.dp)
        )

        // Opciones principales
        val mainOptions = listOf("Opción A", "Opción B", "Opción C")
        mainOptions.forEach { option ->
            Text(
                text = option,
                fontSize = 20.sp,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        selectedOption = "Seleccionado: $option"
                        showSubMenu = true
                    }
                    .padding(16.dp)
                    .background(Color.White)
            )
        }

        // Submenú con fondo difuminado
        if (showSubMenu) {
            Dialog(
                onDismissRequest = { showSubMenu = false },
                properties = DialogProperties(dismissOnClickOutside = true)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable { showSubMenu = false }
                ) {
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .background(Color.White, MaterialTheme.shapes.medium)
                            .padding(16.dp)
                    ) {
                        val subOptions = listOf("Subopción 1", "Subopción 2", "Subopción 3")
                        subOptions.forEach { subOption ->
                            Text(
                                text = subOption,
                                fontSize = 18.sp,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        selectedOption = "Seleccionado: $subOption en $selectedOption"
                                        showSubMenu = false
                                    }
                                    .padding(8.dp)
                            )
                        }
                    }
                }
            }
        }

        Text(
            text = selectedOption,
            fontSize = 18.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .background(Color.White)
        )
    }
}