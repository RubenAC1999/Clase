package com.example.interfaz

import android.os.Bundle
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.interfaz.ui.theme.InterfazTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            InterfazTheme {
                PainterSpinnerWithWebView()
            }
        }
    }
}

data class Painter(
    val image: Int,
    val name: String,
    val description: String,
    val url: String
)

val painterItems = listOf(
    Painter(
        image = R.drawable.gioconda,
        name = "Leonardo da Vinci",
        description = "Pintor del renacimiento",
        url = "https://es.wikipedia.org/wiki/Leonardo_da_Vinci"
    ),
    Painter(
        image = R.drawable.starrynight,
        name = "Vincent van Gogh",
        description = "Pintor postimpresionista",
        url = "https://es.wikipedia.org/wiki/Vincent_van_Gogh"
    ),
    Painter(
        image = R.drawable.guernica,
        name = "Pablo Picasso",
        description = "Pintor cubista",
        url = "https://es.wikipedia.org/wiki/Pablo_Picasso"
    ),
    Painter(
        image = R.drawable.waterlilies,
        name = "Claude Monet",
        description = "Fundador del impresionismo",
        url = "https://es.wikipedia.org/wiki/Claude_Monet"
    ),
    Painter(
        image = R.drawable.persistenceofmemory,
        name = "Salvador Dalí",
        description = "Artista surrealista",
        url = "https://es.wikipedia.org/wiki/Salvador_Dali"
    ),
    Painter(
        image = R.drawable.selfpotrait,
        name = "Frida Kahlo",
        description = "Pintora mexicana conocida por sus autorretratos",
        url = "https://es.wikipedia.org/wiki/Frida_Kahlo"
    )
)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PainterSpinnerWithWebView() {
    var selectedItem by remember { mutableStateOf(painterItems[0]) }
    var expanded by remember { mutableStateOf(false) }

    Column(modifier = Modifier.fillMaxSize()) {
        // Spinner
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp) // Añade un poco de padding
        ) {
            TextField(
                value = selectedItem.name,
                onValueChange = {},
                readOnly = true,
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor() // Asegura que el TextField sea el ancla del menú
            )
            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false }
            ) {
                painterItems.forEach { item ->
                    DropdownMenuItem(
                        text = {
                            PainterItemRow(item)
                        },
                        onClick = {
                            selectedItem = item
                            expanded = false
                        }
                    )
                }
            }
        }

        // WebView
        AndroidView(
            factory = { context ->
                WebView(context).apply {
                    settings.javaScriptEnabled = true

                    // Configura un WebViewClient personalizado
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(
                            view: WebView?,
                            url: String?
                        ): Boolean {
                            // Carga la URL dentro del WebView
                            if (url != null) {
                                view?.loadUrl(url)
                            }
                            return true // Indica que la URL se maneja internamente
                        }
                    }

                    // Carga la URL inicial
                    loadUrl(selectedItem.url)
                }
            },
            update = { webView ->
                // Actualiza la URL del WebView cuando cambia selectedItem
                webView.loadUrl(selectedItem.url)
            },
            modifier = Modifier
                .fillMaxSize()
                .weight(1f) // Ocupa el espacio restante
        )
    }
}

@Composable
fun PainterItemRow(item: Painter) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Image(
            painter = painterResource(id = item.image),
            contentDescription = null,
            modifier = Modifier.size(50.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Column {
            Text(text = item.name, fontWeight = FontWeight.Bold)
            Text(text = item.description, fontSize = 12.sp)
        }
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFFFFFFF)
@Composable
fun PreviewAndroidVersionList() {
    InterfazTheme {
        PainterSpinnerWithWebView()
    }
}