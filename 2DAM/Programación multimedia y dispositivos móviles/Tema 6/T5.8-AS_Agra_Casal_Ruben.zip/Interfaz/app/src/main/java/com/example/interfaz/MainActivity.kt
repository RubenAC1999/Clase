package com.example.interfaz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.DialogProperties
import java.time.LocalDateTime

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            AppGestorAvisos()
        }
    }
}

data class Cliente(
    val id: Int,
    val nombre: String,
    val tipo: String,
    val telefono: String,
    val direccion: String
)

data class Aviso(
    val id: Int,
    val clienteId: Int,
    val tipoAveria: String,
    val descripcion: String,
    val fechaHora: LocalDateTime,
    var estado: String,
    var tecnicoId: Int?,
    var facturaId: Int?
)

data class Tecnico(
    val id: Int,
    val nombre: String,
    val especialidad: String,
    val experiencia: Int
)

data class Factura(
    val id: Int,
    val avisoId: Int,
    val clienteId: Int,
    val monto: Double,
    val estado: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppGestorAvisos() {
    var pantalla by remember { mutableStateOf("principal") }
    var clientes by remember { mutableStateOf(listOf<Cliente>()) }
    var avisos by remember { mutableStateOf(listOf<Aviso>()) }
    var tecnicos by remember { mutableStateOf(listOf<Tecnico>()) }
    var facturas by remember { mutableStateOf(listOf<Factura>()) }

    var clienteSeleccionado by remember { mutableStateOf<Cliente?>(null) }
    var mostrarDialogo by remember { mutableStateOf(false) }

    var mostrarDialogoFactura by remember { mutableStateOf(false) }
    var facturaSeleccionada by remember { mutableStateOf<Factura?>(null) }

    // Menú principal
    if (pantalla == "principal") {
        Column(
            modifier = Modifier.fillMaxSize(),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Botones de gestión
            Button(onClick = { pantalla = "clientes" }) {
                Text("Gestión de Clientes")
            }
            Button(onClick = { pantalla = "avisos" }) {
                Text("Gestión de Avisos")
            }
            Button(onClick = { pantalla = "tecnicos" }) {
                Text("Gestión de Técnicos")
            }
            Button(onClick = { pantalla = "facturas" }) {
                Text("Gestión de Facturas")
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Botones de listado
            Text("Listados:", style = MaterialTheme.typography.titleMedium)

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {
                Button(onClick = { pantalla = "lista_clientes" }) {
                    Text("Clientes")
                }
                Button(onClick = { pantalla = "lista_avisos" }) {
                    Text("Avisos")
                }
                Button(onClick = { pantalla = "lista_tecnicos" }) {
                    Text("Técnicos")
                }
            }
        }
    }

// Pantallas de listado
    if (pantalla == "lista_clientes") {
        SimpleListScreen(
            title = "Listado de Clientes",
            items = clientes,
            onBack = { pantalla = "principal" }
        ) { cliente ->
            Text("${cliente.nombre} - ${cliente.tipo}")
        }
    }

    if (pantalla == "lista_avisos") {
        SimpleListScreen(
            title = "Listado de Avisos",
            items = avisos,
            onBack = { pantalla = "principal" }
        ) { aviso ->
            val cliente = clientes.find { it.id == aviso.clienteId }
            Text("Aviso #${aviso.id} - ${cliente?.nombre ?: "Cliente desconocido"}")
        }
    }

    if (pantalla == "lista_tecnicos") {
        SimpleListScreen(
            title = "Listado de Técnicos",
            items = tecnicos,
            onBack = { pantalla = "principal" }
        ) { tecnico ->
            Text("${tecnico.nombre} - ${tecnico.especialidad}")
        }
    }

    // Gestión de clientes
    if (pantalla == "clientes") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Gestión de Clientes") },
                    navigationIcon = {
                        IconButton(onClick = { pantalla = "principal" }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver"
                            )
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    clienteSeleccionado = null
                    mostrarDialogo = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Añadir cliente")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                LazyColumn {
                    items(clientes) { cliente ->
                        ListItem(
                            headlineContent = { Text(cliente.nombre) },
                            supportingContent = { Text(cliente.tipo) },
                            trailingContent = {
                                Row {
                                    IconButton(onClick = {
                                        clienteSeleccionado = cliente
                                        mostrarDialogo = true
                                    }) {
                                        Icon(Icons.Default.Edit, "Editar")
                                    }
                                    IconButton(onClick = {
                                        clientes = clientes.filter { it.id != cliente.id }
                                    }) {
                                        Icon(Icons.Default.Delete, "Eliminar")
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Diálogo para clientes
    if (mostrarDialogo && pantalla == "clientes") {
        var nombre by remember { mutableStateOf(clienteSeleccionado?.nombre ?: "") }
        var tipo by remember { mutableStateOf(clienteSeleccionado?.tipo ?: "") }
        var telefono by remember { mutableStateOf(clienteSeleccionado?.telefono ?: "") }
        var direccion by remember { mutableStateOf(clienteSeleccionado?.direccion ?: "") }

        AlertDialog(
            onDismissRequest = { mostrarDialogo = false },
            properties = DialogProperties()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (clienteSeleccionado == null) "Nuevo cliente" else "Editar cliente",
                    style = MaterialTheme.typography.headlineSmall
                )

                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = tipo,
                    onValueChange = { tipo = it },
                    label = { Text("Tipo") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = telefono,
                    onValueChange = { telefono = it },
                    label = { Text("Teléfono") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = direccion,
                    onValueChange = { direccion = it },
                    label = { Text("Dirección") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TextButton(onClick = { mostrarDialogo = false }) {
                        Text("Cancelar")
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    TextButton(
                        onClick = {
                            val nuevoCliente = Cliente(
                                id = clienteSeleccionado?.id ?: (clientes.maxOfOrNull { it.id }
                                    ?: 0) + 1,
                                nombre = nombre,
                                tipo = tipo,
                                telefono = telefono,
                                direccion = direccion
                            )
                            clientes = if (clienteSeleccionado == null) {
                                clientes + nuevoCliente
                            } else {
                                clientes.map { if (it.id == clienteSeleccionado?.id) nuevoCliente else it }
                            }
                            mostrarDialogo = false
                        }
                    ) {
                        Text("Guardar")
                    }
                }
            }
        }
    }


    var mostrarDialogoAviso by remember { mutableStateOf(false) }
    var avisoSeleccionado by remember { mutableStateOf<Aviso?>(null) }

    // Gestión de avisos
    if (pantalla == "avisos") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Gestión de Avisos") },
                    navigationIcon = {
                        IconButton(onClick = { pantalla = "principal" }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver"
                            )
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    avisoSeleccionado = null
                    mostrarDialogoAviso = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Nuevo aviso")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                LazyColumn {
                    items(avisos) { aviso ->
                        val cliente = clientes.find { it.id == aviso.clienteId }
                        ListItem(
                            headlineContent = { Text("Aviso #${aviso.id}") },
                            supportingContent = {
                                Column {
                                    Text("Cliente: ${cliente?.nombre ?: "Desconocido"}")
                                    Text("Estado: ${aviso.estado}")
                                }
                            },
                            trailingContent = {
                                Row {
                                    IconButton(onClick = {
                                        avisoSeleccionado = aviso
                                        mostrarDialogo = true
                                    }) {
                                        Icon(Icons.Default.Edit, "Editar")
                                    }
                                    IconButton(onClick = {
                                        avisos = avisos.filter { it.id != aviso.id }
                                    }) {
                                        Icon(Icons.Default.Delete, "Eliminar")
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Diálogo para avisos
    if (mostrarDialogoAviso && pantalla == "avisos") {
        var clienteId by remember { mutableStateOf(avisoSeleccionado?.clienteId?.toString() ?: "") }
        var tipoAveria by remember { mutableStateOf(avisoSeleccionado?.tipoAveria ?: "") }
        var descripcion by remember { mutableStateOf(avisoSeleccionado?.descripcion ?: "") }
        var estado by remember { mutableStateOf(avisoSeleccionado?.estado ?: "Pendiente") }
        var tecnicoId by remember { mutableStateOf(avisoSeleccionado?.tecnicoId?.toString() ?: "") }

        var showClientes by remember { mutableStateOf(false) }
        val clienteSeleccionadoNombre =
            clientes.find { it.id.toString() == clienteId }?.nombre ?: "Seleccionar cliente"

        var showTecnicos by remember { mutableStateOf(false) }
        val tecnicoSeleccionadoNombre =
            tecnicos.find { it.id.toString() == tecnicoId }?.nombre ?: "Seleccionar técnico"

        AlertDialog(
            onDismissRequest = { mostrarDialogoAviso = false },
            properties = DialogProperties()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (avisoSeleccionado == null) "Nuevo aviso" else "Editar aviso",
                    style = MaterialTheme.typography.headlineSmall
                )

                // Selector de cliente
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showClientes = true }
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "Cliente",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = clienteSeleccionadoNombre,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Divider(
                            modifier = Modifier.fillMaxWidth(),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        )
                    }

                    DropdownMenu(
                        expanded = showClientes,
                        onDismissRequest = { showClientes = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        if (clientes.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No hay clientes disponibles") },
                                onClick = { showClientes = false }
                            )
                        } else {
                            clientes.forEach { cliente ->
                                DropdownMenuItem(
                                    text = { Text(cliente.nombre) },
                                    onClick = {
                                        clienteId = cliente.id.toString()
                                        showClientes = false
                                    }
                                )
                            }
                        }
                    }
                }

                // Selector de técnico
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showTecnicos = true }
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "Técnico",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = tecnicoSeleccionadoNombre,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Divider(
                            modifier = Modifier.fillMaxWidth(),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        )
                    }

                    DropdownMenu(
                        expanded = showTecnicos,
                        onDismissRequest = { showTecnicos = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        if (tecnicos.isEmpty()) {
                            DropdownMenuItem(
                                text = { Text("No hay técnicos disponibles") },
                                onClick = { showTecnicos = false }
                            )
                        } else {
                            tecnicos.forEach { tecnico ->
                                DropdownMenuItem(
                                    text = { Text(tecnico.nombre) },
                                    onClick = {
                                        tecnicoId = tecnico.id.toString()
                                        showTecnicos = false
                                    }
                                )
                            }
                        }
                    }
                }

                OutlinedTextField(
                    value = tipoAveria,
                    onValueChange = { tipoAveria = it },
                    label = { Text("Tipo de avería") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = descripcion,
                    onValueChange = { descripcion = it },
                    label = { Text("Descripción") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = false,
                    maxLines = 3
                )

                // Selector de estado
                var showEstados by remember { mutableStateOf(false) }
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showEstados = true }
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "Estado",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = estado,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Divider(
                            modifier = Modifier.fillMaxWidth(),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        )
                    }

                    DropdownMenu(
                        expanded = showEstados,
                        onDismissRequest = { showEstados = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        listOf("Pendiente", "En proceso", "Solucionado").forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status) },
                                onClick = {
                                    estado = status
                                    showEstados = false
                                }
                            )
                        }
                    }
                }

                // Botón para factura si está solucionado
                if (estado == "Solucionado") {
                    val factura = facturas.find { it.avisoId == avisoSeleccionado?.id }

                    Button(
                        onClick = {
                            facturaSeleccionada = factura
                            mostrarDialogoFactura = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(if (factura == null) "Crear factura" else "Editar factura")
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { mostrarDialogoAviso = false }) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            val nuevoAviso = Aviso(
                                id = avisoSeleccionado?.id ?: (avisos.maxOfOrNull { it.id }
                                    ?: 0) + 1,
                                clienteId = clienteId.toIntOrNull() ?: 0,
                                tipoAveria = tipoAveria,
                                descripcion = descripcion,
                                fechaHora = LocalDateTime.now(),
                                estado = estado,
                                tecnicoId = tecnicoId.toIntOrNull(),
                                facturaId = facturas.find { it.avisoId == avisoSeleccionado?.id }?.id
                            )
                            avisos = if (avisoSeleccionado == null) {
                                avisos + nuevoAviso
                            } else {
                                avisos.map { if (it.id == avisoSeleccionado?.id) nuevoAviso else it }
                            }
                            mostrarDialogoAviso = false
                        }
                    ) {
                        Text("Guardar")
                    }
                }
            }
        }
    }

    var mostrarDialogoTecnico by remember { mutableStateOf(false) }
    var tecnicoSeleccionado by remember { mutableStateOf<Tecnico?>(null) }

    // Gestión de técnicos
    if (pantalla == "tecnicos") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Gestión de Técnicos") },
                    navigationIcon = {
                        IconButton(onClick = { pantalla = "principal" }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver"
                            )
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    tecnicoSeleccionado = null
                    mostrarDialogoTecnico = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Nuevo técnico")
                }
            }
        ) { padding ->
            Column(Modifier.padding(padding)) {
                LazyColumn {
                    items(tecnicos) { tecnico ->
                        ListItem(
                            headlineContent = { Text(tecnico.nombre) },
                            supportingContent = { Text(tecnico.especialidad) },
                            trailingContent = {
                                Row {
                                    IconButton(onClick = {
                                        tecnicoSeleccionado = tecnico
                                        mostrarDialogoTecnico = true
                                    }) {
                                        Icon(Icons.Default.Edit, "Editar")
                                    }
                                    IconButton(onClick = {
                                        tecnicos = tecnicos.filter { it.id != tecnico.id }
                                    }) {
                                        Icon(Icons.Default.Delete, "Eliminar")
                                    }
                                }
                            }
                        )
                    }
                }
            }
        }
    }

    // Diálogo para técnicos
    if (mostrarDialogoTecnico && pantalla == "tecnicos") {
        var nombre by remember { mutableStateOf(tecnicoSeleccionado?.nombre ?: "") }
        var especialidad by remember { mutableStateOf(tecnicoSeleccionado?.especialidad ?: "") }
        var experiencia by remember {
            mutableStateOf(
                tecnicoSeleccionado?.experiencia?.toString() ?: ""
            )
        }

        AlertDialog(
            onDismissRequest = { mostrarDialogoTecnico = false },
            properties = DialogProperties()
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (tecnicoSeleccionado == null) "Nuevo técnico" else "Editar técnico",
                    style = MaterialTheme.typography.headlineSmall
                )

                OutlinedTextField(
                    value = nombre,
                    onValueChange = { nombre = it },
                    label = { Text("Nombre") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = especialidad,
                    onValueChange = { especialidad = it },
                    label = { Text("Especialidad") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = experiencia,
                    onValueChange = { experiencia = it },
                    label = { Text("Experiencia (años)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { mostrarDialogoTecnico = false }) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            val nuevoTecnico = Tecnico(
                                id = tecnicoSeleccionado?.id ?: (tecnicos.maxOfOrNull { it.id }
                                    ?: 0) + 1,
                                nombre = nombre,
                                especialidad = especialidad,
                                experiencia = experiencia.toIntOrNull() ?: 0
                            )
                            tecnicos = if (tecnicoSeleccionado == null) {
                                tecnicos + nuevoTecnico
                            } else {
                                tecnicos.map { if (it.id == tecnicoSeleccionado?.id) nuevoTecnico else it }
                            }
                            mostrarDialogoTecnico = false
                        }
                    ) {
                        Text("Guardar")
                    }
                }
            }
        }
    }

    // Añadir al estado global


// Diálogo para facturas
    if (mostrarDialogoFactura) {
        var monto by remember { mutableStateOf(facturaSeleccionada?.monto?.toString() ?: "") }
        var estado by remember { mutableStateOf(facturaSeleccionada?.estado ?: "Pendiente") }

        AlertDialog(
            onDismissRequest = { mostrarDialogoFactura = false },
            properties = DialogProperties()
        ) {
            Column(
                modifier = Modifier.padding(16.dp).background(Color.White),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = if (facturaSeleccionada == null) "Nueva factura" else "Editar factura",
                    style = MaterialTheme.typography.headlineSmall
                )

                OutlinedTextField(
                    value = monto,
                    onValueChange = { monto = it },
                    label = { Text("Monto (€)") },
                    modifier = Modifier.fillMaxWidth(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )

                // Selector de estado de factura
                var showEstadosFactura by remember { mutableStateOf(false) }
                Box(modifier = Modifier.fillMaxWidth()) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showEstadosFactura = true }
                            .padding(vertical = 8.dp)
                    ) {
                        Text(
                            text = "Estado",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = estado,
                            style = MaterialTheme.typography.bodyLarge,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                        Divider(
                            modifier = Modifier.fillMaxWidth(),
                            thickness = 1.dp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.12f)
                        )
                    }

                    DropdownMenu(
                        expanded = showEstadosFactura,
                        onDismissRequest = { showEstadosFactura = false },
                        modifier = Modifier.fillMaxWidth(0.9f)
                    ) {
                        listOf("Pagada", "Pendiente").forEach { status ->
                            DropdownMenuItem(
                                text = { Text(status) },
                                onClick = {
                                    estado = status
                                    showEstadosFactura = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = { mostrarDialogoFactura = false }) {
                        Text("Cancelar")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    TextButton(
                        onClick = {
                            val nuevaFactura = Factura(
                                id = facturaSeleccionada?.id ?: (facturas.maxOfOrNull { it.id }
                                    ?: 0) + 1,
                                avisoId = avisoSeleccionado?.id ?: 0,
                                clienteId = avisoSeleccionado?.clienteId ?: 0,
                                monto = monto.toDoubleOrNull() ?: 0.0,
                                estado = estado
                            )
                            facturas = if (facturaSeleccionada == null) {
                                facturas + nuevaFactura
                            } else {
                                facturas.map { if (it.id == facturaSeleccionada?.id) nuevaFactura else it }
                            }
                            mostrarDialogoFactura = false
                        }
                    ) {
                        Text("Guardar")
                    }
                }
            }
        }
    }

    if (pantalla == "facturas") {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Gestión de Facturas") },
                    navigationIcon = {
                        IconButton(onClick = { pantalla = "principal" }) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = "Volver"
                            )
                        }
                    }
                )
            },
            floatingActionButton = {
                FloatingActionButton(onClick = {
                    facturaSeleccionada = null
                    mostrarDialogoFactura = true
                }) {
                    Icon(Icons.Default.Add, contentDescription = "Añadir factura")
                }
            }
        ) { padding ->
            Surface(
                modifier = Modifier.fillMaxSize(),
                color = MaterialTheme.colorScheme.background // Usa el color de fondo del tema
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    LazyColumn {
                        items(facturas) { factura ->
                            val aviso = avisos.find { it.id == factura.avisoId }
                            val cliente = clientes.find { it.id == factura.clienteId }
                            ListItem(
                                headlineContent = { Text("Factura #${factura.id}") },
                                supportingContent = {
                                    Column {
                                        Text("Aviso: ${aviso?.id ?: "Desconocido"}")
                                        Text("Cliente: ${cliente?.nombre ?: "Desconocido"}")
                                        Text("Monto: ${factura.monto} €")
                                        Text("Estado: ${factura.estado}")
                                    }
                                },
                                trailingContent = {
                                    Row {
                                        IconButton(onClick = {
                                            facturaSeleccionada = factura
                                            mostrarDialogoFactura = true
                                        }) {
                                            Icon(Icons.Default.Edit, "Editar")
                                        }
                                        IconButton(onClick = {
                                            facturas = facturas.filter { it.id != factura.id }
                                        }) {
                                            Icon(Icons.Default.Delete, "Eliminar")
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

    // Componente reutilizable para listados
    @OptIn(ExperimentalMaterial3Api::class)
    @Composable
    fun <T> SimpleListScreen(
        title: String,
        items: List<T>,
        onBack: () -> Unit,
        itemContent: @Composable (T) -> Unit
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text(title) },
                    navigationIcon = {
                        IconButton(onClick = onBack) {
                            Icon(Icons.Default.ArrowBack, "Volver")
                        }
                    }
                )
            }
        ) { padding ->
            LazyColumn(modifier = Modifier.padding(padding)) {
                items(items) { item ->
                    ListItem(
                        headlineContent = { itemContent(item) }
                    )
                    Divider()
                }
            }
        }
    }

