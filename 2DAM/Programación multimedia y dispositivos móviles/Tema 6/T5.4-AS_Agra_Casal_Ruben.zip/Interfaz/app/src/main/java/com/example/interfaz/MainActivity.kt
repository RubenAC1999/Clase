package com.example.interfaz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.interfaz.ui.theme.InterfazTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
                    AndroidVersionList()
            }
        }
    }


data class AndroidVersion(
    val name : String,
    val secondText : String,
    val icon : Int = R.drawable.ic_launcher_background
)

val androidVersions = listOf(
    AndroidVersion("APPLE PIE", "Otro texto"),
    AndroidVersion("BANANA BREAD", "Otro texto"),
    AndroidVersion("CUPCAKE", "Otro texto"),
    AndroidVersion("DONUT", "Otro texto"),
    AndroidVersion("ÉCLAIR", "Otro texto"),
    AndroidVersion("FROYO", "Otro texto"),
    AndroidVersion("GINGERBREAD", "Otro texto"),
    AndroidVersion("HONEYCOMB", "Otro texto")
)


@Composable
fun AndroidVersionList() {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .background(Color.Gray)
    ) {
        Text(
            text = "EJEMPLO DE LISTADO",
            color = Color.White,
            fontSize = 18.sp
        )
    }
    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {
        items(androidVersions) { version -> listItem(version = version)
        }
    }
}

@Composable
fun listItem(version : AndroidVersion) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(3.dp)
            .fillMaxWidth()
            .background(Color.LightGray) // Fondo gris claro
            .padding(16.dp) // Espaciado interno
    ) {
        SuperposedIcons(
            backgroundIcon = R.drawable.ic_launcher_background,
            foregroundIcon = R.drawable.ic_launcher_foreground
        )

        Spacer(modifier = Modifier.size(8.dp))

        Column (
            modifier = Modifier.weight(1f),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ){
            Text(
                text = version.name,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )

            Text(
                text = version.secondText,
                fontSize = 12.sp,
                color = Color.Gray
            )
        }

        Spacer(modifier = Modifier.size(8.dp))

        SuperposedIcons(
            backgroundIcon = R.drawable.ic_launcher_background,
            foregroundIcon = R.drawable.ic_launcher_foreground
        )

    }
}


@Composable
fun SuperposedIcons(backgroundIcon: Int, foregroundIcon: Int) {
    Box(
        modifier = Modifier.size(48.dp)
    ) {
        Image(
            painter = painterResource(id = backgroundIcon),
            contentDescription = "Ícono de fondo",
            modifier = Modifier
                .size(55.dp)
                .align(Alignment.Center)
                .clip(CircleShape)
        )

        Image(
            painter = painterResource(id = foregroundIcon),
            contentDescription = "Ícono de primer plano",
            modifier = Modifier
                .size(55.dp)
                .align(Alignment.Center),
        )
    }
}

@Preview(showBackground = true, backgroundColor = 0xFFFFFFFF)
@Composable
fun PreviewAndroidVersionList() {
    InterfazTheme {
        AndroidVersionList()
    }
}