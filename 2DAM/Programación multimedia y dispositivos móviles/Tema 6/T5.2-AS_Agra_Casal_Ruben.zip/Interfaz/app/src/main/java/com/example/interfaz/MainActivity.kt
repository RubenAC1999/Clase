package com.example.interfaz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.interfaz.ui.theme.InterfazTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
           RegistrationScreen()
        }
    }
}

@Composable
fun RegistrationScreen(modifier: Modifier = Modifier) {
    val name = remember { mutableStateOf("") }
    val gender = remember { mutableStateOf("") }
    val interests = remember { mutableStateListOf<String>() }
    val showInfo = remember { mutableStateOf(false) }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .padding(
                top = 32.dp,
                start = 16.dp,
                end = 16.dp,
                bottom = 16.dp
            ),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        // Campo de nombre (sin cambios)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Nombre: ")
            BasicTextField(
                value = name.value,
                onValueChange = { name.value = it },
                modifier = Modifier.padding(8.dp)
            )
        }

        // Género - Corregido
        Text("Género: ")
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {

            // Masculino
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { gender.value = "Masculino" }
            ) {
                RadioButton(
                    selected = gender.value == "Masculino",
                    onClick = { gender.value = "Masculino" } // Corregido aquí
                )
                Text("Masculino", modifier = Modifier.padding(start = 4.dp))
            }

            // Femenino
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier
                    .clickable { gender.value = "Femenino" }
            ) {
                RadioButton(
                    selected = gender.value == "Femenino",
                    onClick = { gender.value = "Femenino" }
                )
                Text("Femenino", modifier = Modifier.padding(start = 4.dp))
            }
        }

        // Intereses - Corregido
        Text("Intereses: ")
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Videojuegos", "Cine", "Deportes").forEach { interest ->
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clickable {
                            if (interests.contains(interest)) {
                                interests.remove(interest)
                            } else {
                                interests.add(interest)
                            }
                        }
                        .padding(4.dp)
                ) {
                    Checkbox(
                        checked = interests.contains(interest), // Corregido aquí
                        onCheckedChange = null
                    )
                    Text(interest, modifier = Modifier.padding(start = 4.dp))
                }
            }
        }

        // Botón de registro
        Button(
            onClick = { showInfo.value = true },
            modifier = Modifier
                .padding(20.dp)
                .align(Alignment.CenterHorizontally)
        ) {
            Text("Registrar")
        }

        if(showInfo.value) {
            val result = buildString {
                append("Nombre:  ${name.value}\n")
                    .append("Género: ${gender.value}\n")
                    .append("Intereses: ${interests.joinToString()}\n")
            }
            Text(
                text = result
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun RegistrationScreenPreview() {
    RegistrationScreen()
}



