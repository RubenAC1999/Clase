package com.example.interfaz

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Button
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.text.input.KeyboardType

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            ProductScreenPreview()
        }
    }
}

data class Producto(
    val nombre: String,
    val precio: Double
)

val productos = listOf(
    Producto("Camiseta", 25.99),
    Producto("Pantalón", 49.99),
    Producto("Zapatos", 79.99),
    Producto("Bufanda", 15.50)
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProductScreen() {
    var expanded by remember { mutableStateOf(false) }
    var selectedProduct by remember { mutableStateOf<Producto?>(null) }
    var cantidad by remember { mutableStateOf("") }
    var total by remember { mutableStateOf(0.0) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(
                top = 32.dp
            ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Selector de producto
        ExposedDropdownMenuBox(
            expanded = expanded,
            onExpandedChange = { expanded = !expanded }
        ) {
            TextField(
                modifier = Modifier
                    .fillMaxWidth()
                    .menuAnchor(),
                readOnly = true,
                value = selectedProduct?.nombre ?: "Seleccione un producto",
                onValueChange = {},
                label = { Text("Producto") },
                trailingIcon = {
                    ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded)
                }
            )

            ExposedDropdownMenu(
                expanded = expanded,
                onDismissRequest = { expanded = false } // Corregido el nombre de la propiedad
            ) {
                productos.forEach { producto ->
                    DropdownMenuItem(
                        text = { Text("${producto.nombre} - $${producto.precio}") },
                        onClick = {
                            selectedProduct = producto
                            expanded = false
                        }
                    )
                }
            }
        }

        // Campo de cantidad
        TextField(
            value = cantidad,
            onValueChange = { cantidad = it},
            label = { Text("Cantidad") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                val precio = selectedProduct?.precio?: 0.0
                val cantidadValue = cantidad.toIntOrNull() ?: 0
                total = precio * cantidadValue
            },
            modifier = Modifier.align(Alignment.End)
        ) {
            Text("Calcular total")
        }

        Text(
            text = "Total: ${total}$"
        )
    }
}

@Preview(showBackground = true)
@Composable
fun ProductScreenPreview() {
    ProductScreen()
}



