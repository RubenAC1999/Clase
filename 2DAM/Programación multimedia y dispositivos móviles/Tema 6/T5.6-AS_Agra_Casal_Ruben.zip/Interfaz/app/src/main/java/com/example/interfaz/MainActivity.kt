package com.example.interfaz;
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            ContextMenuApp()
        }
    }
}

@Composable
fun ContextMenuApp() {
    var showMenu by remember { mutableStateOf(false) }
    var selectedOption by remember { mutableStateOf("") }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFC7D0FF))
    ) {
        // Contenido principal
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Texto superior
            Text(
                text = "Programación multimedia y dispositivos móviles",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(bottom = 32.dp)
            )

            // Texto central con menú contextual
            Text(
                text = "Mantén pulsado para el menú",
                fontSize = 20.sp,
                fontWeight = FontWeight.Medium,
                modifier = Modifier
                    .clickable { showMenu = true } // Activa el menú al hacer clic largo
                    .padding(16.dp)
            )

            // Texto inferior para mostrar la opción seleccionada
            Text(
                text = selectedOption,
                fontSize = 18.sp,
                modifier = Modifier.padding(top = 32.dp)
            )
        }

        // Menú contextual (superpuesto)
        if (showMenu) {
            Dialog(
                onDismissRequest = { showMenu = false },
                properties = DialogProperties(dismissOnClickOutside = true)
            ) {
                // Fondo difuminado
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Color.Black.copy(alpha = 0.5f))
                        .clickable { showMenu = false } // Cierra el menú al tocar fuera
                ) {
                    // Menú de opciones
                    Column(
                        modifier = Modifier
                            .align(Alignment.Center)
                            .background(Color.White, MaterialTheme.shapes.medium)
                            .padding(16.dp)
                    ) {
                        Text(
                            text = "Opción 1",
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedOption = "Opción 1 seleccionada"
                                    showMenu = false
                                }
                                .padding(8.dp)
                        )
                        Text(
                            text = "Opción 2",
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedOption = "Opción 2 seleccionada"
                                    showMenu = false
                                }
                                .padding(8.dp)
                        )
                        Text(
                            text = "Opción 3",
                            fontSize = 18.sp,
                            modifier = Modifier
                                .clickable {
                                    selectedOption = "Opción 3 seleccionada"
                                    showMenu = false
                                }
                                .padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}