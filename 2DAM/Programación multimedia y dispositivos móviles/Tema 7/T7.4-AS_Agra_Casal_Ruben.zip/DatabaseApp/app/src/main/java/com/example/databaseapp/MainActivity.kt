package com.example.databaseapp

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SimpleDatabaseApp()
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SimpleDatabaseApp() {
    val context = LocalContext.current
    val dbHelper = remember { DatabaseHelper(context) }
    var text1 by remember { mutableStateOf("") }
    var text2 by remember { mutableStateOf("") }
    var data by remember { mutableStateOf<List<String>>(emptyList()) }
    var selectedItemId by remember { mutableStateOf<String?>(null) }
    var showDeleteDialog by remember { mutableStateOf(false) }
    var showEditDialog by remember { mutableStateOf(false) }
    val coroutineScope = rememberCoroutineScope()

    // Función para cargar los datos
    fun loadData() {
        val cursor = dbHelper.recogerDatos()
        val tempData = mutableListOf<String>()
        if (cursor.moveToFirst()) {
            do {
                val id = cursor.getString(0)
                val t1 = cursor.getString(1)
                val t2 = cursor.getString(2)
                tempData.add("ID: $id, Text1: $t1, Text2: $t2")
            } while (cursor.moveToNext())
        }
        cursor.close()
        data = tempData
    }

    Column(modifier = Modifier.padding(16.dp)) {
        TextField(
            value = text1,
            onValueChange = { text1 = it },
            label = { Text("Texto 1") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        TextField(
            value = text2,
            onValueChange = { text2 = it },
            label = { Text("Texto 2") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(16.dp))

        Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
            Button(onClick = {
                if (text1.isNotEmpty() && text2.isNotEmpty()) {
                    dbHelper.insertarDatos(text1, text2)
                    loadData()
                    text1 = ""
                    text2 = ""
                    Toast.makeText(context, "Datos insertados", Toast.LENGTH_SHORT).show()
                }
            }, Modifier.weight(1f)) {
                Text("Insertar")
            }
            Button(onClick = { loadData() }, Modifier.weight(1f)) {
                Text("Listar")
            }
            Button(onClick = {
                if (selectedItemId != null) {
                    showDeleteDialog = true
                } else {
                    Toast.makeText(context, "Selecciona un elemento para borrar", Toast.LENGTH_SHORT).show()
                }
            }, Modifier.weight(1f)) {
                Text("Borrar")
            }
            Button(onClick = {
                if (selectedItemId != null && text1.isNotEmpty() && text2.isNotEmpty()) {
                    showEditDialog = true
                } else {
                    Toast.makeText(context, "Selecciona un elemento y completa los campos para modificar", Toast.LENGTH_SHORT).show()
                }
            }, Modifier.weight(1f)) {
                Text("Modificar")
            }
        }
        Spacer(modifier = Modifier.height(16.dp))

        LazyColumn {
            items(data) { item ->
                Text(
                    text = item,
                    modifier = Modifier
                        .padding(8.dp)
                        .clickable {
                            selectedItemId = item.split(",")[0].split(": ")[1]
                        }
                )
            }
        }
    }

    if (showDeleteDialog) {
        AlertDialog(
            onDismissRequest = { showDeleteDialog = false },
            title = { Text("Confirmar Borrado") },
            text = { Text("¿Estás seguro de que quieres borrar este registro?") },
            confirmButton = {
                TextButton(onClick = {
                    selectedItemId?.let { id ->
                        dbHelper.borrarDatos(id)
                        loadData()
                        Toast.makeText(context, "Registro borrado", Toast.LENGTH_SHORT).show()
                    }
                    showDeleteDialog = false
                }) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showDeleteDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }

    if (showEditDialog) {
        AlertDialog(
            onDismissRequest = { showEditDialog = false },
            title = { Text("Confirmar Modificación") },
            text = { Text("¿Estás seguro de que quieres modificar este registro?") },
            confirmButton = {
                TextButton(onClick = {
                    selectedItemId?.let { id ->
                        dbHelper.actualizarDatos(id, text1, text2)
                        loadData()
                        Toast.makeText(context, "Registro modificado", Toast.LENGTH_SHORT).show()
                    }
                    showEditDialog = false
                }) {
                    Text("Confirmar")
                }
            },
            dismissButton = {
                TextButton(onClick = { showEditDialog = false }) {
                    Text("Cancelar")
                }
            }
        )
    }
}