package com.example.sharedpreferencesapp

import android.content.Context
import android.graphics.Outline
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.BufferedReader
import java.io.File
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.FileOutputStream
import java.io.IOException
import java.io.InputStreamReader

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            internalStorageApp()
        }
    }
}

@Composable
fun internalStorageApp() {
    val context = LocalContext.current

    var text1 by remember { mutableStateOf("") }
    var savedText1 by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = text1,
            onValueChange = { text1 = it },
            label = { Text("Ingrese un texto") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    guardarEnTarjetaSD(context, text1)
                    savedText1 = "Datos guardados: $text1"
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                   val valor = leerDesdeTarjetaSD(context)

                   savedText1 = "Valor: $valor"

                },
                Modifier.fillMaxWidth()
            ) {
                Text("Recuperar")
            }

        Text(
            text = savedText1,
            fontSize = 18.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )

    }

}

private fun guardarEnTarjetaSD(context: Context, valor: String) {
    try {
        val rutaSD = File("/storage/emulated/0/")
        val archivo = File(rutaSD, "datos.txt")

        val fileOutputStream = FileOutputStream(archivo)
        fileOutputStream.write(valor.toByteArray())
        fileOutputStream.close()

    } catch(e: IOException) {
        e.printStackTrace()
    }
}

private fun leerDesdeTarjetaSD(context: Context): String {
    var valor = StringBuilder()
    try {
        val rutaSD = File("/storage/emulated/0/")
        val archivo = File(rutaSD, "datos.txt")

        val fileInputStream = FileInputStream(archivo)
        val inputStreamReader = InputStreamReader(fileInputStream)
        val bufferedReader = BufferedReader(inputStreamReader)
       var line: String?

        while (bufferedReader.readLine().also { line = it } != null) {
            valor.append(line)
        }

        bufferedReader.close()

    } catch (e: FileNotFoundException) {
        valor.append("Archivo no encontrado")
    } catch (e: IOException) {
        valor.append("Error al leer")
    }

    return valor.toString()
}