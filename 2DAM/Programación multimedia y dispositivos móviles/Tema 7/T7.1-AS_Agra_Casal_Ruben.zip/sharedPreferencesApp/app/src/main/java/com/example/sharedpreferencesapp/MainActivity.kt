package com.example.sharedpreferencesapp

import android.content.Context
import android.graphics.Outline
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            sharedPreferencesApp()
        }
    }
}

@Composable
fun sharedPreferencesApp() {
    val context = LocalContext.current

    var text1 by remember { mutableStateOf("") }
    var text2 by remember { mutableStateOf("") }

    var savedText1 by remember { mutableStateOf("") }
    var savedText2 by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        OutlinedTextField(
            value = text1,
            onValueChange = { text1 = it },
            label = { Text("Ingrese el primer texto") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

        OutlinedTextField(
            value = text2,
            onValueChange = { text2 = it },
            label = { Text("Inrese el segundo texto") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    val sharedPreferences = context.getSharedPreferences("mis_preferencias",
                        Context.MODE_PRIVATE)

                    val editor = sharedPreferences.edit()
                    editor.putString("clave1", text1)
                    editor.putString("clave2", text2)
                    editor.apply()

                    savedText1 = "Datos guardados:  $text1, $text2"
                },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Guardar")
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val sharedPreferences = context.getSharedPreferences("mis_preferencias",
                        Context.MODE_PRIVATE)

                    val valor1 = sharedPreferences.getString("clave1", "No hay valor guardado")
                    val valor2 = sharedPreferences.getString("clave2", "No hay valor guardado")

                    savedText1 = "Valor 1: $valor1"
                    savedText2 = "Valor 2: $valor2"
                },
                Modifier.fillMaxWidth()
            ) {
                Text("Recuperar")
            }

        Text(
            text = savedText1,
            fontSize = 18.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )

        Text(
            text = savedText2,
            fontSize = 18.sp,
            modifier = Modifier.padding(vertical = 8.dp)
        )

    }

}