package com.example.buttonapp

import android.R.attr.button
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.graphics.Typeface

class Screen4 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout4)

        val recoverButton : Button = findViewById(R.id.recoverButton)
        val transformButton : Button = findViewById(R.id.transformButton)
        val textView : TextView = findViewById(R.id.screen4TextView)

        transformButton.setOnClickListener {
            textView.setTypeface(Typeface.MONOSPACE)

        }

        recoverButton.setOnClickListener {
          textView.setTypeface(Typeface.DEFAULT)
        }

    }
}