package com.example.buttonapp

import android.R.attr.button
import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.graphics.Typeface

class Screen3 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout3)

        val recoverButton : Button = findViewById(R.id.recoverButton)
        val transformButton : Button = findViewById(R.id.transformButton)
        val textView : TextView = findViewById(R.id.screen3TextView)

        transformButton.setOnClickListener {
            textView.setTextColor(resources.getColor(R.color.purple_700))

        }

        recoverButton.setOnClickListener {
            textView.setTextColor(Color.RED)
            textView.text = "El contenido del TextView original"
            textView.setTextSize(24F)
        }

    }
}