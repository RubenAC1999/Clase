package com.example.buttonapp

import android.annotation.SuppressLint
import android.graphics.Color
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.graphics.Typeface

class Screen2 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout2)

        val button : Button = findViewById(R.id.buttonScreen2)
        val textView : TextView = findViewById(R.id.screen2TextView)

        button.setOnClickListener {
            textView.setTextColor(Color.BLUE)
            textView.setTypeface(null, Typeface.ITALIC)
            textView.text = "Texto introducido desde Java con el tamaño 20dp, italic y color Blue"
            textView.setTextSize(20F)
        }

    }
}