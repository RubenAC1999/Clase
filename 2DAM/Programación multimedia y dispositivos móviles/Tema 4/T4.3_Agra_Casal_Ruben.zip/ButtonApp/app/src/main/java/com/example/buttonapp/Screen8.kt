package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class Screen8 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout8)

        val textView : TextView = findViewById(R.id.screen8TextView)
        val appearButton : Button = findViewById(R.id.appearButton)
        val disappearButton : Button = findViewById(R.id.disappearButton)
        val appearAnimation = AnimationUtils.loadAnimation(this, R.anim.appear_animation)
        val disappearAnimation = AnimationUtils.loadAnimation(this, R.anim.disappear_animation)


        appearButton.setOnClickListener() {
            textView.startAnimation(appearAnimation)
        }
        disappearButton.setOnClickListener() {
            textView.startAnimation(disappearAnimation)
        }
    }
}