package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        val goToScreen1 : Button = findViewById(R.id.goToScreen1Button)
        goToScreen1.setOnClickListener{
            changeScreen(this, Screen1::class.java)
        }

        val goToScreen2 : Button = findViewById(R.id.goToScreen2Button)
        goToScreen2.setOnClickListener{
            changeScreen(this, Screen2::class.java)
        }

        val goToScreen3 : Button = findViewById(R.id.goToScreen3Button)
        goToScreen3.setOnClickListener {
            changeScreen(this, Screen3::class.java)
        }

        val goToScreen4 : Button = findViewById(R.id.goToScreen4Button)
        goToScreen4.setOnClickListener {
            changeScreen(this, Screen4::class.java)
        }

        val goToScreen5 : Button = findViewById(R.id.goToScreen5Button)
        goToScreen5.setOnClickListener {
            changeScreen(this, Screen5::class.java)
        }

        val goToScreen6 : Button = findViewById(R.id.goToScreen6Button)
        goToScreen6.setOnClickListener {
            changeScreen(this, Screen6::class.java)
        }

        val goToScreen7 : Button = findViewById(R.id.goToScreen7Button)
        goToScreen7.setOnClickListener {
            changeScreen(this, Screen7::class.java)
        }

        val goToScreen8 : Button = findViewById(R.id.goToScreen8Button)
        goToScreen8.setOnClickListener {
            changeScreen(this, Screen8::class.java)
        }

        val goToScreen9 : Button = findViewById(R.id.goToScreen9Button)
        goToScreen9.setOnClickListener {
            changeScreen(this, Screen9::class.java)
        }
    }
}

private fun changeScreen(context : Context, destination : Class<*>) {
    val intent = Intent(context, destination)
    context.startActivity(intent)
}