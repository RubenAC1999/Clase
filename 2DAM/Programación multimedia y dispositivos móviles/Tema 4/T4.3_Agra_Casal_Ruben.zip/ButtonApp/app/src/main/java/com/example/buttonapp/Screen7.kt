package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class Screen7 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout7)

        val textView : TextView = findViewById(R.id.screen7TextView)
        val effectButton : Button = findViewById(R.id.effectButton)
        val translateAnimation = AnimationUtils.loadAnimation(this, R.anim.scale_animation)


        effectButton.setOnClickListener() {
            textView.startAnimation(translateAnimation)
        }
    }
}