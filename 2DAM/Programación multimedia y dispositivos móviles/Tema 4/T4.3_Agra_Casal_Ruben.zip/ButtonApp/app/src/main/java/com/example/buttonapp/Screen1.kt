package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.graphics.Typeface

class Screen1 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout1)

        val button : Button = findViewById(R.id.buttonScreen1)
        val textView : TextView = findViewById(R.id.screen1TextView)
        textView.editableText

        button.setOnClickListener {
            textView.setTextColor(0xFFFF0000.toInt())
            textView.setTypeface(null, Typeface.BOLD_ITALIC)
            textView.text = "Botón pulsado"
            textView.setTextSize(18F)
        }

    }
}