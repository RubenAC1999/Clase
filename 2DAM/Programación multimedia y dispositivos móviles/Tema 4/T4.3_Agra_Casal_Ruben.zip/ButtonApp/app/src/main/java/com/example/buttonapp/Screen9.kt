package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class Screen9 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout9)

        val textView : TextView = findViewById(R.id.screen9TextView)
        val combination1Button : Button = findViewById(R.id.combinationAButton)
        val combination2Button : Button = findViewById(R.id.combinationBButton)
        val combination1Animation = AnimationUtils.loadAnimation(this, R.anim.combined_animation1)
        val combination2Animation = AnimationUtils.loadAnimation(this, R.anim.combined_animation2)

        combination1Button.setOnClickListener() {
            textView.startAnimation(combination1Animation)
        }
        combination2Button.setOnClickListener() {
            textView.startAnimation(combination2Animation)
        }

    }
}