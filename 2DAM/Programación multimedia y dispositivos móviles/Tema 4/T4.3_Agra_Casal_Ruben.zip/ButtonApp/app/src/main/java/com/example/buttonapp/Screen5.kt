package com.example.buttonapp

import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class Screen5 : ComponentActivity() {
    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout5)

        val textView : TextView = findViewById(R.id.screen5TextView)
        val effectButton : Button = findViewById(R.id.effectButton)
        val translateAnimation = AnimationUtils.loadAnimation(this, R.anim.translate_animation)


        effectButton.setOnClickListener() {
            textView.startAnimation(translateAnimation)
        }
    }
}