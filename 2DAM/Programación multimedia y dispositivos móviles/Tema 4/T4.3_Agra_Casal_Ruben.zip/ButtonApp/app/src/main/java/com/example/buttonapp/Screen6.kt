package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.animation.AnimationUtils
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class Screen6 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState : Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout6)

        val textView : TextView = findViewById(R.id.screen6TextView)
        val effectButton : Button = findViewById(R.id.effectButton)
        val translateAnimation = AnimationUtils.loadAnimation(this, R.anim.rotate_animation)


        effectButton.setOnClickListener() {
            textView.startAnimation(translateAnimation)
        }
    }
}