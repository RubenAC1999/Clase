package com.example.diceroller

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val rollButton : Button = findViewById(R.id.rollButton)
        rollButton.setOnClickListener {
            rollDice()
        }
    }

    private fun rollDice(){
       val dice = Dice(6)
        val diceResult = dice.roll()
        val diceResult2 = dice.roll()
        val resultTextView : TextView = findViewById(R.id.resultTextView)
        val resultTextView2 : TextView = findViewById(R.id.resultTextView2)
        resultTextView.text = diceResult.toString()
        resultTextView2.text = diceResult2.toString()
    }
}

class Dice (val numSides : Int) {

    fun roll() : Int {
        return (1..numSides).random()
    }
}

