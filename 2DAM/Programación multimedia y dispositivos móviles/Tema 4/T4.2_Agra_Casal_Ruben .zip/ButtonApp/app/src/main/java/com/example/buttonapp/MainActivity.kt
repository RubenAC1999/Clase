package com.example.buttonapp

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)

        val goToScreen1 : Button = findViewById(R.id.goToScreen1Button)
        goToScreen1.setOnClickListener{
            changeScreen(this, Screen1::class.java)
        }

        val goToScreen2 : Button = findViewById(R.id.goToScreen2Button)
        goToScreen2.setOnClickListener{
            changeScreen(this, Screen2::class.java)
        }

        val goToScreen3 : Button = findViewById(R.id.goToScreen3Button)
        goToScreen3.setOnClickListener {
            changeScreen(this, Screen3::class.java)
        }

        val goToScreen4 : Button = findViewById(R.id.goToScreen4Button)
        goToScreen4.setOnClickListener {
            changeScreen(this, Screen4::class.java)
        }
    }
}

private fun changeScreen(context : Context, destination : Class<*>) {
    val intent = Intent(context, destination)
    context.startActivity(intent)
}