package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.activity.ComponentActivity
import android.graphics.Typeface
import androidx.core.content.res.ResourcesCompat

class Screen4 : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.screenlayout4)

        val recoverButton : Button = findViewById(R.id.recoverButton)
        val transformButton : Button = findViewById(R.id.transformButton)
        val textView : TextView = findViewById(R.id.screen4TextView)
        val customFont = ResourcesCompat.getFont(this, R.font.coolvetica)

        transformButton.setOnClickListener {
            textView.setTypeface(customFont)

        }

        recoverButton.setOnClickListener {
          textView.setTypeface(Typeface.DEFAULT)
        }

    }
}