package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity
import android.widget.ArrayAdapter
import android.widget.AutoCompleteTextView
import android.widget.CheckBox
import android.widget.Toast

class RegisterActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.registerlayout)

        val ocupaciones = arrayOf(
            "Doctor",
            "Ingeniero",
            "Profesor",
            "Artista",
            "Chef"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, ocupaciones)
        val autoCompleteTextView =
            findViewById<AutoCompleteTextView>(R.id.occupyAutoCompleteTextView)
        autoCompleteTextView.setAdapter(adapter)
        autoCompleteTextView.threshold = 1


        val registerButton : Button = findViewById(R.id.registerButton)
        registerButton.setOnClickListener {
            val conditionsCheckBox : CheckBox = findViewById(R.id.conditionsCheckBox)
            if(conditionsCheckBox.isChecked) {
                Toast.makeText(this, "Registro correcto", Toast.LENGTH_LONG).show()
                this.startActivity(Intent(this, MainActivity::class.java))

            } else {
                Toast.makeText(this,"Debe aceptar las condiciones de protección de datos.", Toast.LENGTH_LONG).show()
            }
        }



    }
}