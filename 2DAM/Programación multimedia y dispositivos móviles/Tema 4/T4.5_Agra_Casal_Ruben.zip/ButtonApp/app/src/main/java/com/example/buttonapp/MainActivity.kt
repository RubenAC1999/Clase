package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity


class MainActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)


        val goToRegisterButton: Button = findViewById(R.id.goToRegisterButton)
        goToRegisterButton.setOnClickListener {
            changeScreen(this, RegisterActivity::class.java)
        }

        val goToPreferencesButton: Button = findViewById(R.id.goToPreferencesButton)
        goToPreferencesButton.setOnClickListener {
            changeScreen(this, PreferencesActivity::class.java)
        }

        val goToSettingsButton: Button = findViewById(R.id.goToSettingsButton)
        goToSettingsButton.setOnClickListener {
            changeScreen(this, SettingsActivity::class.java)
        }
    }


    private fun changeScreen(context: Context, destination: Class<*>) {
        val intent = Intent(context, destination)
        context.startActivity(intent)
    }
}