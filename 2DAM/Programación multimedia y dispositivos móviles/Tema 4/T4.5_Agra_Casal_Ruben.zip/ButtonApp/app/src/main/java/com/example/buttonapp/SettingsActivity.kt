package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.animation.RotateAnimation
import android.widget.Button
import android.widget.ImageView
import android.widget.ProgressBar
import android.widget.TextView
import androidx.activity.ComponentActivity

class SettingsActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.settingslayout)

        val progressBar: ProgressBar = findViewById(R.id.loadProgressBar)
        val loadTextView: TextView = findViewById(R.id.loadTextView)
        val loadImage: ImageView = findViewById(R.id.loadImage)
        loadImage.setImageResource(R.drawable.cargar)
        val loadButton: Button = findViewById(R.id.loadButton)

        loadButton.setOnClickListener {
            progressBar.visibility = ProgressBar.VISIBLE
            loadTextView.text = "Cargando..."
            loadTextView.visibility = TextView.VISIBLE
            loadImage.visibility = ImageView.VISIBLE
            progressBar.progress = 0

            val rotateAnimation = RotateAnimation(0f, 360f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f,
                RotateAnimation.RELATIVE_TO_SELF, 0.5f
            )

            rotateAnimation.duration = 2000
            rotateAnimation.repeatCount = RotateAnimation.INFINITE
            loadImage.startAnimation(rotateAnimation)

            val handler = Handler(Looper.getMainLooper())
            var progress = 0

            val updateProgress = object : Runnable {
                override fun run() {
                    progress += 10
                    progressBar.progress = progress

                    if (progress < 100) {
                        handler.postDelayed(this, 300)
                    } else {
                        loadImage.clearAnimation()
                        loadTextView.visibility = TextView.VISIBLE
                        loadImage.visibility = ImageView.INVISIBLE
                        loadTextView.text = "Completado!"
                    }
                }
            }

            handler.post(updateProgress)
        }

        val returnButton: Button = findViewById(R.id.backSettingsButton)
        returnButton.setOnClickListener {
            this.startActivity(Intent(this, MainActivity::class.java))
        }

    }
}