package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import android.widget.Toast
import android.widget.ToggleButton


class PreferencesActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.preferenceslayout)

        val changeThemeButton: ToggleButton = findViewById(R.id.changeThemeToggleButton)

        changeThemeButton.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
               changeThemeButton.setBackgroundColor(Color.BLACK)
            } else {
                changeThemeButton.setBackgroundColor(Color.WHITE)
            }
        }

        val categorias = arrayOf(
            "Arte",
            "Tecnología",
            "Deporte"
        )

        val spinner = findViewById<Spinner>(R.id.categoriesSpinner)

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, categorias)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinner.adapter = adapter

        spinner.setOnItemSelectedListener(object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>, view: android.view.View?, position: Int, id: Long) {
                val selectedItem = parent.getItemAtPosition(position).toString()
                Toast.makeText(this@PreferencesActivity, "Seleccionaste: $selectedItem", Toast.LENGTH_SHORT).show()
            }

            override fun onNothingSelected(parent: android.widget.AdapterView<*>) {
            }
        })


        val returnButton: Button = findViewById(R.id.backButton)
        returnButton.setOnClickListener {
            this.startActivity(Intent(this, MainActivity::class.java))
        }


    }
}

