package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.MenuInflater
import android.view.View
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity


class SubMenuActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.submenulayout)

        val textoMenu: TextView = findViewById(R.id.optionSubMenu)
        textoMenu.setOnClickListener { view ->
            mostrarPopupMenu(view)
        }

    }

    private fun mostrarPopupMenu(view: View) {
        val popup = PopupMenu(this, view)
        val inflater: MenuInflater = popup.menuInflater
        inflater.inflate(R.menu.submenu, popup.menu)

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.inicio_option -> mostrarMensaje("Inicio seleccionado")
                R.id.tarifas_option -> mostrarSubmenu(view)
                R.id.productos_option -> mostrarMensaje("Productos seleccionado")
                R.id.contacto_option -> mostrarMensaje("Contacto seleccionado")
            }
            true
        }
        popup.show()
    }

    private fun mostrarMensaje(mensaje : String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }

    private fun mostrarSubmenu(view: View) {
        val submenuPopup = PopupMenu(this, view)
        val inflater: MenuInflater = submenuPopup.menuInflater
        inflater.inflate(R.menu.submenu, submenuPopup.menu)

        submenuPopup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.basica_option -> mostrarMensaje("Tarifa Básica seleccionada")
                R.id.estandar_option -> mostrarMensaje("Tarifa Estándar seleccionada")
                R.id.premium_option -> mostrarMensaje("Tarifa Premium seleccionada")
                R.id.empresarial_option -> mostrarMensaje("Tarifa Empresarial seleccionada")
            }
            true
        }
        submenuPopup.show()
    }

}

