package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.ContextMenu
import android.view.MenuInflater
import android.view.View
import android.widget.TextView
import androidx.activity.ComponentActivity


class MenuContextualActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menucontextuallayout)
        val textViewMenu: TextView = findViewById(R.id.menuContextualTextView)

        registerForContextMenu(textViewMenu)
    }

    override fun onCreateContextMenu(menu: ContextMenu?, v: View?, menuInfo: ContextMenu.ContextMenuInfo?) {
        super.onCreateContextMenu(menu, v, menuInfo)
        val inflater: MenuInflater = menuInflater
        inflater.inflate(R.menu.menucontextual, menu)
    }

    override fun onContextItemSelected(item: android.view.MenuItem): Boolean {
        return when (item.itemId) {
            R.id.inicio_option -> {
                mostrarMensaje("Inicio seleccionado")
                true
            }
            R.id.tarifas_option -> {
                mostrarMensaje("Tarifas seleccionado")
                true
            }
            R.id.productos_option -> {
                mostrarMensaje("Productos seleccionado")
                true
            }
            R.id.contacto_option -> {
                mostrarMensaje("Contacto seleccionado")
                true
            }
            else -> super.onContextItemSelected(item)
        }
    }

    private fun mostrarMensaje(mensaje: String) {
        android.widget.Toast.makeText(this, mensaje, android.widget.Toast.LENGTH_SHORT).show()
    }
}