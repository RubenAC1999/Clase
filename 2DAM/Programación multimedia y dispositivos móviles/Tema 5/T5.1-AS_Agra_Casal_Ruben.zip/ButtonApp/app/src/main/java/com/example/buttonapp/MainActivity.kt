package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity


class MainActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)


        val goToMenuButton: Button = findViewById(R.id.goToMenuButton)
        goToMenuButton.setOnClickListener {
            changeScreen(this, MenuActivity::class.java)
        }

        val goToSubmenuButton : Button = findViewById(R.id.goToSubmenuButton)
        goToSubmenuButton.setOnClickListener {
            changeScreen(this, SubMenuActivity::class.java)
        }

        val goToContextualMenuButton: Button = findViewById(R.id.goToContextualMenuButton)
        goToContextualMenuButton.setOnClickListener {
            changeScreen(this, MenuContextualActivity::class.java)
        }
    }


    private fun changeScreen(context: Context, destination: Class<*>) {
        val intent = Intent(context, destination)
        context.startActivity(intent)
    }
}