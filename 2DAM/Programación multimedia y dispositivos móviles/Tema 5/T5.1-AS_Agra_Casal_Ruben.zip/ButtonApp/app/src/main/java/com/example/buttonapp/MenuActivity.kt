package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.PopupMenu
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity

class MenuActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.menulayout)

        val textoMenu: TextView = findViewById(R.id.optionMenu)
        textoMenu.setOnClickListener { view ->
            mostrarPopupMenu(view)
        }
    }

     private fun mostrarPopupMenu(view: View) {
        val popup = PopupMenu(this, view)
        val inflater: MenuInflater = popup.menuInflater
        inflater.inflate(R.menu.main_menu, popup.menu)

        popup.setOnMenuItemClickListener { item ->
            when (item.itemId) {
                R.id.inicio_option -> mostrarMensaje("Inicio seleccionado")
                R.id.tarifas_option -> mostrarMensaje("Tarifas seleccionado")
                R.id.productos_option -> mostrarMensaje("Productos seleccionado")
                R.id.contacto_option -> mostrarMensaje("Contacto seleccionado")
            }
            true
        }
        popup.show()
    }

    private fun mostrarMensaje(mensaje : String) {
        Toast.makeText(this, mensaje, Toast.LENGTH_SHORT).show()
    }

}