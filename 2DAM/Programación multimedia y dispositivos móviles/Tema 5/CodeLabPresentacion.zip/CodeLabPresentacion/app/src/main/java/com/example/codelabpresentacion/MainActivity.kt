package com.example.codelabpresentacion

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlin.compareTo
import kotlin.random.Random

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val navController: NavController = rememberNavController()
            NavHost(
                navController = navController as NavHostController,
                startDestination = "GameScreen"
            ) {
                composable("BusinessCardScreen") { BusinessCardScreen(navController) }
                composable("InfoScreen") { InfoScreen(navController) }
                composable("SensorScreen") { SensorScreen(navController) }
                composable("GameScreen") { GameScreen(navController)}
            }
        }
    }
}

@Composable
fun BusinessCardScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE3F2FD)),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(100.dp)
                .background(Color.White),
            contentAlignment = Alignment.Center,
        ) {
            Text(text = "Imagen", color = Color.Gray)
        }

        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                modifier = Modifier
                    .padding(10.dp),
                text = "Rubén Agra Casal",
                fontWeight = FontWeight.Bold
            )
            Text(
                text = "2º DAM",
                color = Color.Gray
            )
        }
        Column(
            modifier = Modifier
                .width(300.dp)
                .padding(8.dp),
            horizontalAlignment = Alignment.Start
        ) {
            ContactRow(icon = Icons.Default.Phone, text = "981 82 82 82")
            ContactRow(icon = Icons.Default.Email, text = "a24rubenac@iesantonlosada.gal")
            ContactRow(icon = Icons.Default.Person, text = "@socialmediahandle")
        }
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier.fillMaxWidth()
        ) {
            buttonOption("Sensores") {
                navController.navigate("SensorScreen")
            }
            buttonOption("Juego") {
                navController.navigate("GameScreen")
            }
            buttonOption("Información") {
                navController.navigate("InfoScreen")
            }
        }
    }
}

@Composable
fun ContactRow(icon: ImageVector, text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(vertical = 8.dp)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            modifier = Modifier.size(24.dp),
            tint = Color.Black
        )
        Spacer(modifier = Modifier.width(16.dp))
        Text(text = text)
    }
}

@Composable
fun buttonOption(text: String, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = Color.Black
        )
    ) {
        Text(
            text = text
        )
    }
}

@Composable
fun InfoScreen(navController: NavController) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE3F2FD))
            .padding(top = 40.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Pantalla de Información",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Spacer(modifier = Modifier.size(40.dp))

        infoRow("Modelo: ", Build.MODEL)
        infoRow("Fabricante: ", Build.MANUFACTURER)
        infoRow("Versión de Android: ", Build.VERSION.RELEASE)
        infoRow("Resolución de pantalla: ", "2000x1200")

        Spacer(modifier = Modifier.size(40.dp))
       Button(
           onClick = {
               navController.navigate("BusinessCardScreen")
           },
           colors = ButtonDefaults.buttonColors(
               containerColor = Color.Black
           )
       ) {
           Text(
               text = "Atrás"
           )
       }
    }
}

@Composable
fun infoRow(infoType: String, info: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Start
    ) {
        Text(
            text = infoType,
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Text(
            text = info,
            fontSize = 18.sp,
        )
    }
}

@Composable
fun SensorScreen(navController: NavController) {
    Column (
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE3F2FD))
            .padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Lista de sensores",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )
        Spacer(modifier = Modifier.size(20.dp))

        sensorInfo()

        Spacer(modifier = Modifier.size(20.dp))

        Button(
            onClick = {
                navController.navigate("BusinessCardScreen")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black
            )
        ) {
            Text(
                text = "Atrás"
            )
        }
    }
}


@Composable
fun sensorInfo() {
    val context = LocalContext.current
    val sensorManager = context.getSystemService(Context.SENSOR_SERVICE) as SensorManager
    val accelerometerInfo = sensorManager.getSensorList(Sensor.TYPE_ACCELEROMETER)
    val gyroscopeInfo = sensorManager.getSensorList(Sensor.TYPE_GYROSCOPE)
    val magneticFieldInfo = sensorManager.getSensorList(Sensor.TYPE_MAGNETIC_FIELD)
    val lightSensorInfo = sensorManager.getSensorList(Sensor.TYPE_LIGHT)

    Column(modifier = Modifier.padding(13.dp)) {
        Text(
            modifier = Modifier.padding(10.dp),
            text = "Información del acelerómetro",
            fontSize = 18.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
        accelerometerInfo.forEach { sensor ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sensor: ${sensor.name}, \nTipo: ${sensor.stringType}",
                    color = Color.Black,
                )
            }
        }
        Text(
            modifier = Modifier.padding(10.dp),
            text = "Información del giroscopio",
            fontSize = 18.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
        gyroscopeInfo.forEach { sensor ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sensor: ${sensor.name}, \nTipo: ${sensor.stringType}",
                    color = Color.Black
                )
            }
        }
        Text(
            modifier = Modifier.padding(10.dp),
            text = "Información del campo magnético",
            fontSize = 18.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
        magneticFieldInfo.forEach { sensor ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sensor: ${sensor.name}, \nTipo: ${sensor.stringType}",
                    color = Color.Black,
                )
            }
        }
        Text(
            modifier = Modifier.padding(10.dp),
            text = "Información del sensor de luz",
            fontSize = 18.sp,
            color = Color.Black,
            fontWeight = FontWeight.Bold
        )
        lightSensorInfo.forEach { sensor ->
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Sensor: ${sensor.name}, \nTipo: ${sensor.stringType}",
                    color = Color.Black,
                )
            }
        }
    }
}

data class CardData(
    val id: Int,
    val imageRes: Int,
    var isFlipped: Boolean = false,
    var isMatched: Boolean = false
)

@Composable
fun GameScreen(navController: NavController) {
    val initialCards = remember { generateCards() }
    var cardsState by remember { mutableStateOf(initialCards) }
    var flippedCards by remember { mutableStateOf(listOf<CardData>()) }
    var moves by remember { mutableStateOf(0) }
    var isClickEnabled by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFE3F2FD)),
    )

    fun handleCardClick(card: CardData) {
        if (isClickEnabled && !card.isFlipped && !card.isMatched) {
            val updatedCards = cardsState.map {
                if (it.id == card.id) it.copy(isFlipped = true) else it
            }
            cardsState = updatedCards

            flippedCards = flippedCards + card

            if (flippedCards.size == 2) {
                moves++
                val firstCard = flippedCards[0]
                val secondCard = flippedCards[1]

                if (firstCard.imageRes == secondCard.imageRes) {
                    cardsState = cardsState.map {
                        if (it.id == firstCard.id || it.id == secondCard.id) {
                            it.copy(isMatched = true)
                        } else it
                    }
                    flippedCards = emptyList()
                } else {
                    isClickEnabled = false
                    Handler(Looper.getMainLooper()).postDelayed({
                        cardsState = cardsState.map {
                            if (it.id == firstCard.id || it.id == secondCard.id) {
                                it.copy(isFlipped = false)
                            } else it
                        }
                        flippedCards = emptyList()
                        isClickEnabled = true
                    }, 1000)
                }
            }
        }
    }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier.fillMaxSize()
    ) {
        Text("Moves: $moves", fontSize = 24.sp, color = Color.Black)

        Spacer(modifier = Modifier.height(20.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            modifier = Modifier.fillMaxWidth(),

        ) {
            items(cardsState.size) { index ->
                val card = cardsState[index]
                MemoryCard(card = card, onClick = { handleCardClick(card) })
            }
        }

    }
}

@Composable
fun MemoryCard(card: CardData, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(80.dp)
            .padding(8.dp)
            .clickable(onClick = onClick)
            .background(Color(0xFFE3F2FD))
            .padding(4.dp),
        contentAlignment = Alignment.Center
    ) {
        if (card.isFlipped || card.isMatched) {
            Image(
                painter = painterResource(id = card.imageRes),
                contentDescription = "Card Image",
                modifier = Modifier.
                    size(80.dp)
                    .background(Color.White, shape = RoundedCornerShape(8.dp))
            )
        } else {
            Box(
                modifier = Modifier
                    .size(80.dp)
                    .background(Color.LightGray, shape = RoundedCornerShape(8.dp)),
                contentAlignment = Alignment.Center
            ) {
                Text("?", fontSize = 32.sp, color = Color.Black)
            }
        }
    }
}

fun generateCards(): List<CardData> {
    val images = listOf(
        R.drawable.circle,
        R.drawable.cross,
        R.drawable.heart,
        R.drawable.hexagon,
        R.drawable.pentagon,
        R.drawable.rectangle,
        R.drawable.rhombus,
        R.drawable.square,
        R.drawable.star,
        R.drawable.triangle
    )

    val cards = mutableListOf<CardData>()

    for (imageRes in images) {
        cards.add(CardData(id = Random.nextInt(), imageRes = imageRes))
        cards.add(CardData(id = Random.nextInt(), imageRes = imageRes))
    }

    cards.shuffle()

    return cards
}