package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.activity.ComponentActivity

class SpinnerActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.spinnerviewlayout)

        val carList : Spinner = findViewById(R.id.carDialogSpinner)
        val carList2 : Spinner = findViewById(R.id.carDropdownSpinner)

        val cars1 = listOf("Dialog Spinner", "Toyota Corolla", "Honda Civic", "Ford Mustang", "Chevrolet Camaro",
                "Volkswagen Golf", "BMW Serie 3", "Mercedes-Benz Clase C", "Audi A4", "Nissan Altima",
                "Hyundai Tucson", "Tesla Model 3", "Peugeot 208", "Renault Clio")
        val cars2 = listOf("Dropdown Spinner", "Toyota Corolla", "Honda Civic", "Ford Mustang", "Chevrolet Camaro",
            "Volkswagen Golf", "BMW Serie 3", "Mercedes-Benz Clase C", "Audi A4", "Nissan Altima",
            "Hyundai Tucson", "Tesla Model 3", "Peugeot 208", "Renault Clio")

        val adapter1 = ArrayAdapter(this, android.R.layout.simple_list_item_1, cars1)
        val adapter2 = ArrayAdapter(this, android.R.layout.simple_list_item_1, cars2)

        carList.adapter = adapter1
        carList2.adapter = adapter2
    }
}