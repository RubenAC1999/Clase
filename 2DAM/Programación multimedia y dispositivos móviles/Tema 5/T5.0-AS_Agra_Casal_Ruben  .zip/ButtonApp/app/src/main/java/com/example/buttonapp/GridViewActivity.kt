package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.GridView
import androidx.activity.ComponentActivity


class GridViewActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.gridviewlayout)

        val capitalList : GridView = findViewById(R.id.gridView)
        val capitals = listOf("Madrid", "París", "Lisboa", "Berlín", "Amsterdam", "Roma", "Londres",
            "Bruselas", "Viena", "Atenas", "Oslo", "Dublín")
        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, capitals)

        capitalList.adapter = adapter
    }
}

