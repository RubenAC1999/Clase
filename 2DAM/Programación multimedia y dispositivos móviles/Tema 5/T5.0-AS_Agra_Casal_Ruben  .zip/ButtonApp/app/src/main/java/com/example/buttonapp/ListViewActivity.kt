package com.example.buttonapp

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import androidx.activity.ComponentActivity

class ListViewActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.listviewlayout)
        val countryList : ListView = findViewById(R.id.countriesListView)

        val countries = listOf(
            "España",
            "Francia",
            "Portugal",
            "Alemania",
            "Países Bajos",
            "Suiza",
            "Suecia",
            "Noruega",
            "Bélgica",
            "Rusia"
        )

        val adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, countries)

        countryList.adapter = adapter;

    }

}