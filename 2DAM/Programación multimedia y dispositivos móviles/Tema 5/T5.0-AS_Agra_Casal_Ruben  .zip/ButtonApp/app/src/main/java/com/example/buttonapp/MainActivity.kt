package com.example.buttonapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.activity.ComponentActivity


class MainActivity : ComponentActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main_activity)


        val goToListViewButton: Button = findViewById(R.id.goToListViewButton)
        goToListViewButton.setOnClickListener {
            changeScreen(this, ListViewActivity::class.java)
        }

        val goToGridViewButton : Button = findViewById(R.id.goToGridViewButton)
        goToGridViewButton.setOnClickListener {
            changeScreen(this, GridViewActivity::class.java)
        }

        val goToSpinnerButton: Button = findViewById(R.id.goToSpinnerButton)
        goToSpinnerButton.setOnClickListener {
            changeScreen(this, SpinnerActivity::class.java)
        }
    }


    private fun changeScreen(context: Context, destination: Class<*>) {
        val intent = Intent(context, destination)
        context.startActivity(intent)
    }
}