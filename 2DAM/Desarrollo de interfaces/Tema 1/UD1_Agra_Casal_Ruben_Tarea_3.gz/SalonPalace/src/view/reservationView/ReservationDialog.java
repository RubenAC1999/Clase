
package view.reservationView;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class ReservationDialog extends javax.swing.JDialog {

    
    public ReservationDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    public void addMakeReservationButtonActionListener(ActionListener listener) {
        this.makeReservationButton.addActionListener(listener);
    }
    
    public void addCancelButtonActionListener(ActionListener listener) {
        this.cancelButton.addActionListener(listener);
    }
    
    public void addCleanFieldsButtonActionListener(ActionListener listener) {
        this.cleanFieldsButton.addActionListener(listener);
    }
    
    public void cleanFields() {
        this.nameTextField.setText("");
        this.emailTextField.setText("");
        this.phoneNumberTextField.setText("");
        this.setDateTextField("");
        this.setNumberAttendeesSpinnerValue(1);
        this.setReserveRoomsCheckBox(false);
    }
    
    public boolean isAnyTextFieldBlank() {
        String[] textFields = {getNameTextField(), getEmailTextField(), 
            getPhoneNumberTextField()
        };
        
        for(String tf : textFields) {
            if (tf.isBlank()) {
                return true;
            }
        }
        
        return false;
    }
    
    public String getNameTextField() {
        return this.nameTextField.getText();
    }
    
    public String getEmailTextField() {
        return this.emailTextField.getText();
    }
    
    public String getPhoneNumberTextField() {
        return this.phoneNumberTextField.getText();
    }
    
    public String getDateTextField() {
        return this.dateTextField.getText();
    }
    
    public String getNumberAttendeesSpinnerValue() {
        return numberAttendeesSpinner.getValue().toString();
    }
    
    public String getSelectedOption() {
        String option = null;
        if (optionButtonGroup.getSelection() != null) {
            option = optionButtonGroup.getSelection().getActionCommand();
        }
        
        return option;
    }
    
    public String getKitchenServiceOption() {
        return this.kitchenServiceComboBox.getSelectedItem().toString();
    }
    
    public boolean isReserveRoomsChecked() {
        return this.reserveRoomsCheckBox.isSelected();
    }
    
    private void setNameTextField(String name) {
        this.nameTextField.setText(name);
    }
    
    private void setEmailTextField(String email) {
        this.emailTextField.setText(email);
    }
    
    private void setPhoneNumberTextField(String phoneNumber) {
        this.phoneNumberTextField.setText(phoneNumber);
    }
    
    private void setDateTextField(String date) {
        this.dateTextField.setText("");
    }
    
    private void setNumberAttendeesSpinnerValue(int number) {
        this.numberAttendeesSpinner.setValue((Integer) number);
    }
    
    private void setReserveRoomsCheckBox(boolean isReserved) {
        this.reserveRoomsCheckBox.setSelected(isReserved);
    }
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        optionButtonGroup = new javax.swing.ButtonGroup();
        titleLabel = new javax.swing.JLabel();
        nameLabel = new javax.swing.JLabel();
        nameTextField = new javax.swing.JTextField();
        emailLabel = new javax.swing.JLabel();
        emailTextField = new javax.swing.JTextField();
        phoneNumberLabel = new javax.swing.JLabel();
        phoneNumberTextField = new javax.swing.JTextField();
        eventTypeLabel = new javax.swing.JLabel();
        feastOptionRadioButton = new javax.swing.JRadioButton();
        congressOptionRadioButton = new javax.swing.JRadioButton();
        dayOptionRadioButton = new javax.swing.JRadioButton();
        kitchenServiceLabel = new javax.swing.JLabel();
        kitchenServiceComboBox = new javax.swing.JComboBox<>();
        reserveRoomsCheckBox = new javax.swing.JCheckBox();
        makeReservationButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        cleanFieldsButton = new javax.swing.JButton();
        dateLabel = new javax.swing.JLabel();
        dateTextField = new javax.swing.JTextField();
        numberAttendeesLabel = new javax.swing.JLabel();
        numberAttendeesSpinner = new javax.swing.JSpinner();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        titleLabel.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        titleLabel.setText("Salon Palace reservation");

        nameLabel.setText("Name:");

        emailLabel.setText("Email:");

        phoneNumberLabel.setText("Phone number:");

        eventTypeLabel.setText("Event type:");

        optionButtonGroup.add(feastOptionRadioButton);
        feastOptionRadioButton.setText("Feast");
        feastOptionRadioButton.setActionCommand("feast");
        feastOptionRadioButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                feastOptionRadioButtonActionPerformed(evt);
            }
        });

        optionButtonGroup.add(congressOptionRadioButton);
        congressOptionRadioButton.setText("Congress");
        congressOptionRadioButton.setActionCommand("congress");

        optionButtonGroup.add(dayOptionRadioButton);
        dayOptionRadioButton.setText("Day trip");
        dayOptionRadioButton.setActionCommand("day trip");

        kitchenServiceLabel.setText("Kitchen service: ");

        kitchenServiceComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Buffet", "Menu", "Contact with the chef", "No service" }));

        reserveRoomsCheckBox.setText("Reserve rooms for the assistants");

        makeReservationButton.setText("Make reservation");

        cancelButton.setText("Cancel");

        cleanFieldsButton.setText("Clean fields");

        dateLabel.setText("Date:");

        numberAttendeesLabel.setText("Number of attendees:");

        numberAttendeesSpinner.setValue((Integer) 1);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(cancelButton, javax.swing.GroupLayout.PREFERRED_SIZE, 81, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(makeReservationButton, javax.swing.GroupLayout.DEFAULT_SIZE, 150, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(cleanFieldsButton)
                .addGap(29, 29, 29))
            .addGroup(layout.createSequentialGroup()
                .addGap(79, 79, 79)
                .addComponent(reserveRoomsCheckBox)
                .addGap(0, 0, Short.MAX_VALUE))
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(80, 80, 80)
                        .addComponent(titleLabel))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(47, 47, 47)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(nameLabel)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(kitchenServiceLabel)
                                .addGap(18, 18, 18)
                                .addComponent(kitchenServiceComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addComponent(emailLabel)))
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(layout.createSequentialGroup()
                            .addGap(30, 30, 30)
                            .addComponent(numberAttendeesLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(numberAttendeesSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGap(35, 35, 35))
                        .addGroup(javax.swing.GroupLayout.Alignment.LEADING, layout.createSequentialGroup()
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addGroup(layout.createSequentialGroup()
                                    .addGap(57, 57, 57)
                                    .addComponent(eventTypeLabel)
                                    .addGap(29, 29, 29))
                                .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                                    .addGap(45, 45, 45)
                                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(dateLabel)
                                        .addComponent(phoneNumberLabel))
                                    .addGap(18, 18, 18)))
                            .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(congressOptionRadioButton)
                                .addComponent(feastOptionRadioButton)
                                .addComponent(dayOptionRadioButton)
                                .addComponent(nameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(emailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(phoneNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(dateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 122, javax.swing.GroupLayout.PREFERRED_SIZE)))))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(titleLabel)
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(nameLabel)
                    .addComponent(nameTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(emailLabel)
                    .addComponent(emailTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(phoneNumberLabel)
                    .addComponent(phoneNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 23, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(12, 12, 12)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(dateLabel)
                    .addComponent(dateTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(numberAttendeesLabel)
                    .addComponent(numberAttendeesSpinner, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(feastOptionRadioButton)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(eventTypeLabel)
                    .addComponent(congressOptionRadioButton))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(dayOptionRadioButton)
                .addGap(36, 36, 36)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(kitchenServiceComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(kitchenServiceLabel))
                .addGap(26, 26, 26)
                .addComponent(reserveRoomsCheckBox)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(makeReservationButton)
                    .addComponent(cancelButton)
                    .addComponent(cleanFieldsButton))
                .addContainerGap(27, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void feastOptionRadioButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_feastOptionRadioButtonActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_feastOptionRadioButtonActionPerformed

  
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton cancelButton;
    private javax.swing.JButton cleanFieldsButton;
    private javax.swing.JRadioButton congressOptionRadioButton;
    private javax.swing.JLabel dateLabel;
    private javax.swing.JTextField dateTextField;
    private javax.swing.JRadioButton dayOptionRadioButton;
    private javax.swing.JLabel emailLabel;
    private javax.swing.JTextField emailTextField;
    private javax.swing.JLabel eventTypeLabel;
    private javax.swing.JRadioButton feastOptionRadioButton;
    private javax.swing.JComboBox<String> kitchenServiceComboBox;
    private javax.swing.JLabel kitchenServiceLabel;
    private javax.swing.JButton makeReservationButton;
    private javax.swing.JLabel nameLabel;
    private javax.swing.JTextField nameTextField;
    private javax.swing.JLabel numberAttendeesLabel;
    private javax.swing.JSpinner numberAttendeesSpinner;
    private javax.swing.ButtonGroup optionButtonGroup;
    private javax.swing.JLabel phoneNumberLabel;
    private javax.swing.JTextField phoneNumberTextField;
    private javax.swing.JCheckBox reserveRoomsCheckBox;
    private javax.swing.JLabel titleLabel;
    // End of variables declaration//GEN-END:variables
}
