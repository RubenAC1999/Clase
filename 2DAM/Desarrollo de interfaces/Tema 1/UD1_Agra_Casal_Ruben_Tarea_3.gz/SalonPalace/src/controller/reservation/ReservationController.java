package controller.reservation;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JOptionPane;
import view.reservationView.ReservationDialog;

public class ReservationController {

    ReservationDialog view;

    public ReservationController(ReservationDialog view) {
        this.view = view;
        this.view.addCleanFieldsButtonActionListener(this.getCleanFieldsButtonActionListener());
        this.view.addMakeReservationButtonActionListener(this.getMakeReservationButtonActionListener());
        this.view.addCancelButtonActionListener(this.getCancelButtonActionListener());
    }

    public ActionListener getCleanFieldsButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.cleanFields();
            }

        };

        return al;
    }

    public ActionListener getCancelButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.dispose();
            }

        };

        return al;
    }

    public ActionListener getMakeReservationButtonActionListener() {

        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (view.getSelectedOption() == null) {
                    JOptionPane.showMessageDialog(view, "Choose an event type.");
                } else if (view.isAnyTextFieldBlank()) {
                    JOptionPane.showMessageDialog(view, "Error: Complete all the fields.");
                } else {

                    String reservationDetails = "Reservation details\n--------------------------------"
                            + "\nName: " + view.getNameTextField()
                            + "\nEmail: " + view.getEmailTextField()
                            + "\nPhone number: " + view.getPhoneNumberTextField()
                            + "\nDate: " + view.getDateTextField()
                            + "\nNumber of attendees: " + view.getNumberAttendeesSpinnerValue()
                            + "\nEvent type: " + view.getSelectedOption()
                            + "\nKitchen service: " + view.getKitchenServiceOption()
                            + (view.isReserveRoomsChecked() ? "\nReserve rooms for the attendees." : "\nDon't reserve rooms for the attendees");

                    JOptionPane.showMessageDialog(view, reservationDetails);

                }

            }

        };

        return al;
    }
}
