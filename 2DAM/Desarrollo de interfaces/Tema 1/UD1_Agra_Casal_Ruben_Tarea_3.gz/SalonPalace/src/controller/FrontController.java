
package controller;

import controller.reservation.ReservationController;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import view.MainJFrame;
import view.reservationView.ReservationDialog;


public class FrontController {
    private MainJFrame view;
    
    public FrontController(MainJFrame view) {
        this.view = view;
        this.view.addQuitMenuItemActionListener(this.getQuitMenuItemActionListener());
        this.view.addMakeReservationMenuItemActionListener(this.getMakeReservationMenuItemActionListener());
    }
    
    public ActionListener getMakeReservationMenuItemActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                ReservationDialog rd = new ReservationDialog(view, true);
                ReservationController rC = new ReservationController(rd);
                rd.setVisible(true);
            }
            
        };
        
        return al;
    }
    
    public ActionListener getQuitMenuItemActionListener() {
           ActionListener al = new ActionListener() {
               @Override
               public void actionPerformed(ActionEvent e) {
                   System.out.println("Clossing app...");
                   view.dispose();
                   System.exit(0);
               }
               
           };
           
           return al;
    }
    
}
