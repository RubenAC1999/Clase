
package main;

import controller.FrontController;
import view.MainJFrame;


public class Main {
    public static void main(String[] args) {
        MainJFrame mainView = new MainJFrame();
        FrontController fc = new FrontController(mainView);
        mainView.setVisible(true);
    }
}
