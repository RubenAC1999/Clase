package controller.computerManagementController;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.Vector;
import javax.swing.JOptionPane;
import model.Ald;
import model.AllInOne;
import model.Computer;
import model.DesktopComputer;
import model.Laptop;
import view.computerManagement.ComputerManagementDialog;

public class ComputerManagementController {

    private ComputerManagementDialog view;
    private Ald ald;

    public ComputerManagementController(ComputerManagementDialog view, Ald ald) {
        this.view = view;
        this.ald = ald;
        this.initComponents();
        this.view.addComputerTypeOptionActionListener(this.getComputerTypeOptionActionListener());
        this.view.addComputerActionListener(this.getAddComputerButtonActionListener());
        this.view.addCancelButtonActionListener(this.getCancelButtonActionListener());
        this.view.addSaveButtonActionListener(this.getSaveButtonActionListener());
        this.view.addComputersTableMouseListener(this.getComputersTableMouseListener());
        this.view.addEditComputerActionListener(this.getEditComputerButtonActionListener());
        this.view.addRemoveComputerActionListener(this.getRemoveComputerButtonActionListener());
        this.view.addComputersScrollPaneMouseListener(this.getComputersScrollPaneMouseListener());
        fillTable();
    }

    private void initComponents() {
        view.clearTextFields();
        view.setAttributeLabelVisibility(false);
        view.setAttributeTextFieldVisibility(false);
        view.setRemoveButtonEnable(false);
        view.setEditButtonEnable(false);
        view.setAddButtonEnable(true);
        view.setSerialNumberTextFieldEnable(false);
        view.setBrandTextFieldEnable(false);
        view.setModelTextFieldEnable(false);
        view.setComputerTypeComboBoxEnable(false);
        view.setAttributeTextFieldEnable(false);
        view.setSaveButtonEnable(false);
        view.setCancelButtonEnable(false);
        view.setComputersTableEnable(true);
        view.setComputersScrollPaneEnable(true);
        view.setMessageLabelText("                                              ");
    }

    public ActionListener getComputerTypeOptionActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
               String computerType = view.getComputerTypeOption();
               
               switch (computerType) {
                case "Desktop Computer" -> {
                    view.setAttributeLabelName("Power supply:");
                    view.setAttributeTextFieldVisibility(true);
                    view.setAttributeLabelVisibility(true);
                }
                case "Laptop" -> {
                    view.setAttributeLabelName("Keyboard layout:");
                    view.setAttributeTextFieldVisibility(true);
                    view.setAttributeLabelVisibility(true);
                }
                case "All in One" -> {
                    view.setAttributeLabelName("Screen resolution:");
                    view.setAttributeTextFieldVisibility(true);
                    view.setAttributeLabelVisibility(true);
                }
                default -> {
                    view.setAttributeLabelVisibility(false);
                    view.setAttributeTextFieldVisibility(false);
                    view.setAttributeTextField("");
                }
            }
            }

        };
        return al;

    }

    public ActionListener getAddComputerButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setAddButtonEnable(false);
                view.setSerialNumberTextFieldEnable(true);
                view.setBrandTextFieldEnable(true);
                view.setModelTextFieldEnable(true);
                view.setComputerTypeComboBoxEnable(true);
                view.setAttributeTextFieldEnable(true);
                view.setSaveButtonEnable(true);
                view.setCancelButtonEnable(true);
                view.setComputersTableEnable(false);
                view.setComputersScrollPaneEnable(false);
                view.setMessageLabelText("                                              ");
            }

        };

        return al;
    }

    public ActionListener getEditComputerButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                view.setSerialNumberTextFieldEnable(true);
                view.setBrandTextFieldEnable(true);
                view.setModelTextFieldEnable(true);
                view.setComputerTypeComboBoxEnable(true);
                view.setAttributeTextFieldEnable(true);
                view.setSaveButtonEnable(true);
                view.setCancelButtonEnable(true);
                view.setRemoveButtonEnable(false);
                view.setEditButtonEnable(false);
                view.setComputersTableEnable(false);
                view.setComputersScrollPaneEnable(false);
            }

        };

        return al;
    }

    public ActionListener getRemoveComputerButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int option = JOptionPane.showConfirmDialog(view, "Are you sure that you want to delete this computer?",
                        "Delete Computer", JOptionPane.INFORMATION_MESSAGE);
                if (option == 0) {
                    ald.deleteComputer(view.getComputerInfo(view.getSelectedRow(), 0));
                    System.out.println("Ordenador borrado");
                    view.clearComputers();
                    fillTable();
                    initComponents();
                    view.setMessageLabelText("Computer deleted succesfully");

                }
            }

        };
        return al;
    }

    public MouseListener getComputersScrollPaneMouseListener() {
        MouseListener ml = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (view.isComputerScrollPaneEnable()) {
                    view.clearSelection();
                    view.setEditButtonEnable(false);
                    initComponents();
                }

            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }

        };

        return ml;
    }

    public MouseListener getComputersTableMouseListener() {
        MouseListener ml = new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
               
                int rowSelected = view.getSelectedRow();
                
                if (rowSelected >= 0 && view.isComputerScrollPaneEnable()) {
                    Computer computerSelected = ald.getComputer(view.getComputerInfo(rowSelected, 0));

                    view.setSerialNumberTextField(computerSelected.getSerialNumber());
                    view.setBrandTextField(computerSelected.getBrand());
                    view.setModelTextField(computerSelected.getModel());

                    if (computerSelected instanceof DesktopComputer) {
                        view.setComputerTypeOption(1);
                        view.setAttributeTextField(((DesktopComputer) computerSelected).getPowerSupply());

                    } else if (computerSelected instanceof Laptop) {
                        view.setComputerTypeOption(2);
                        view.setAttributeTextField(((Laptop) computerSelected).getKeyboardLayout());

                    } else if (computerSelected instanceof AllInOne) {
                        view.setComputerTypeOption(3);
                        view.setAttributeTextField(((AllInOne) computerSelected).getScreenResolution());
                    }
                    view.setAddButtonEnable(false);
                    view.setEditButtonEnable(true);
                    view.setRemoveButtonEnable(true);
                }
            }

            @Override
            public void mousePressed(MouseEvent e) {
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }

        };

        return ml;
    }

    public void fillTable() {
        HashMap<String, Computer> computerList = ald.getComputerList();
        
        for (Map.Entry<String, Computer> entry : computerList.entrySet()) {
            Vector row = new Vector();
            row.add(entry.getKey());
            row.add(entry.getValue().getBrand());
            row.add(entry.getValue().getModel());
                
            if (entry.getValue() instanceof DesktopComputer) {
                row.add("Desktop Computer");
            } else if (entry.getValue() instanceof Laptop) {
                row.add("Laptop");
            } else if (entry.getValue() instanceof AllInOne) {
                row.add("All in One");
            }

            view.addRowTable(row);
        }
    }

    public ActionListener getSaveButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if (!view.isAnyTextFieldBlank()) {
                    Vector row = new Vector();
                    String serialNumberSelected = view.getComputerInfo(view.getSelectedRow(), 0);
                    String newSerialNumber = view.getSerialNumberTextField();
                    String newBrand = view.getBrandTextField();
                    String newModel = view.getModelTextField();
                    String newAttribute = view.getAttributeTextField();
                    String computerType = view.getComputerTypeOption();
                    
                    if (ald.isComputerInTheList(newSerialNumber) && !newSerialNumber.equals(serialNumberSelected)) {
                        view.setMessageLabelText("Serial number is duplicated");
                    } else {
                        if (view.isRowSelected(true)) {
                            ald.deleteComputer(serialNumberSelected);
                        }
                        
                        switch (computerType) {
                            case "Desktop Computer" -> {
                                DesktopComputer dc = new DesktopComputer(newSerialNumber, 
                                newBrand, newModel, newAttribute);
                                ald.addComputer((DesktopComputer) dc);
                            }
                            
                            case "Laptop" -> {
                                Laptop l = new Laptop(newSerialNumber, newBrand, newModel, 
                                newAttribute);
                                ald.addComputer((Laptop) l);
                            }
                            
                            case "All in One" -> {
                                AllInOne aio = new AllInOne(newSerialNumber, newBrand,
                                newModel, newAttribute);
                                ald.addComputer((AllInOne) aio);
                            }
                        }
                        
                        view.clearComputers();
                        fillTable();
                        initComponents();
                    }
                    
                } else {
                    view.setMessageLabelText("You must complete all the fields");
                }
            }

        };

        return al;
    }

    public ActionListener getCancelButtonActionListener() {
        ActionListener al = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                initComponents();
                view.clearSelection();
            }

        };

        return al;
    }
}
