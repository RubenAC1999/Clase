
package view.computerManagement;

import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.util.Vector;
import javax.swing.table.DefaultTableModel;


public class ComputerManagementDialog extends javax.swing.JDialog {

    
    public ComputerManagementDialog(java.awt.Frame parent, boolean modal) {
        super(parent, modal);
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        computerManagementLabel = new javax.swing.JLabel();
        computerManagementTabbedPane = new javax.swing.JTabbedPane();
        computersPanel = new javax.swing.JPanel();
        computersScrollPane = new javax.swing.JScrollPane();
        computersTable = new javax.swing.JTable();
        addComputerButton = new javax.swing.JButton();
        editComputerButton = new javax.swing.JButton();
        removeComputerButton = new javax.swing.JButton();
        serialNumberLabel = new javax.swing.JLabel();
        serialNumberTextField = new javax.swing.JTextField();
        brandLabel = new javax.swing.JLabel();
        modelLabel = new javax.swing.JLabel();
        brandTextField = new javax.swing.JTextField();
        modelTextField = new javax.swing.JTextField();
        computerTypeLabel = new javax.swing.JLabel();
        computerTypeComboBox = new javax.swing.JComboBox<>();
        saveButton = new javax.swing.JButton();
        cancelButton = new javax.swing.JButton();
        attributeLabel = new javax.swing.JLabel();
        attributeTextField = new javax.swing.JTextField();
        messageLabel = new javax.swing.JLabel();
        servicesPanel = new javax.swing.JPanel();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);
        setBackground(new java.awt.Color(204, 204, 255));

        computerManagementLabel.setFont(new java.awt.Font("Liberation Sans", 1, 18)); // NOI18N
        computerManagementLabel.setText("Computer Management");

        computerManagementTabbedPane.setBackground(new java.awt.Color(245, 245, 255));

        computersPanel.setBackground(new java.awt.Color(245, 245, 255));

        computersTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Serial Number", "Brand", "Model", "Type"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.String.class, java.lang.String.class, java.lang.String.class, java.lang.String.class
            };

            @Override
            public Class getColumnClass(int columnIndex) {
                return types[columnIndex];
            }

            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        }
    );
    computersTable.setGridColor(new java.awt.Color(255, 255, 255));
    computersTable.setSelectionBackground(new java.awt.Color(204, 204, 255));
    computersScrollPane.setViewportView(computersTable);

    addComputerButton.setText("Add");

    editComputerButton.setText("Edit");

    removeComputerButton.setBackground(new java.awt.Color(255, 204, 204));
    removeComputerButton.setText("Remove");

    serialNumberLabel.setFont(new java.awt.Font("Liberation Sans", 1, 13)); // NOI18N
    serialNumberLabel.setText("Serial Number: ");

    brandLabel.setFont(new java.awt.Font("Liberation Sans", 1, 13)); // NOI18N
    brandLabel.setText("Brand: ");

    modelLabel.setFont(new java.awt.Font("Liberation Sans", 1, 13)); // NOI18N
    modelLabel.setText("Model: ");

    computerTypeLabel.setFont(new java.awt.Font("Liberation Sans", 1, 13)); // NOI18N
    computerTypeLabel.setText("Type: ");

    computerTypeComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "                     ", "Desktop Computer", "Laptop", "All in One" }));

    saveButton.setText("Save");

    cancelButton.setBackground(new java.awt.Color(255, 204, 204));
    cancelButton.setText("Cancel");

    attributeLabel.setFont(new java.awt.Font("Liberation Sans", 1, 13)); // NOI18N
    attributeLabel.setText("           Attribute: ");

    messageLabel.setForeground(new java.awt.Color(255, 102, 102));
    messageLabel.setText("                                            ");

    javax.swing.GroupLayout computersPanelLayout = new javax.swing.GroupLayout(computersPanel);
    computersPanel.setLayout(computersPanelLayout);
    computersPanelLayout.setHorizontalGroup(
        computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(computersPanelLayout.createSequentialGroup()
            .addComponent(computersScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 669, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addGap(0, 3, Short.MAX_VALUE))
        .addGroup(computersPanelLayout.createSequentialGroup()
            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(computersPanelLayout.createSequentialGroup()
                    .addGap(29, 29, 29)
                    .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                        .addGroup(computersPanelLayout.createSequentialGroup()
                            .addComponent(serialNumberLabel)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addComponent(serialNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(computersPanelLayout.createSequentialGroup()
                            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                .addComponent(modelLabel)
                                .addComponent(brandLabel))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                .addComponent(brandTextField, javax.swing.GroupLayout.DEFAULT_SIZE, 143, Short.MAX_VALUE)
                                .addComponent(modelTextField))))
                    .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                        .addGroup(computersPanelLayout.createSequentialGroup()
                            .addGap(32, 32, 32)
                            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(attributeLabel)
                                .addGroup(computersPanelLayout.createSequentialGroup()
                                    .addGap(47, 47, 47)
                                    .addComponent(computerTypeLabel)))
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                .addComponent(computerTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addComponent(attributeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, 146, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(computersPanelLayout.createSequentialGroup()
                            .addGap(103, 103, 103)
                            .addComponent(saveButton)
                            .addGap(59, 59, 59)
                            .addComponent(cancelButton))))
                .addGroup(computersPanelLayout.createSequentialGroup()
                    .addGap(188, 188, 188)
                    .addComponent(removeComputerButton)
                    .addGap(35, 35, 35)
                    .addComponent(editComputerButton)
                    .addGap(41, 41, 41)
                    .addComponent(addComputerButton)))
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, computersPanelLayout.createSequentialGroup()
            .addGap(0, 0, Short.MAX_VALUE)
            .addComponent(messageLabel)
            .addGap(247, 247, 247))
    );
    computersPanelLayout.setVerticalGroup(
        computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(computersPanelLayout.createSequentialGroup()
            .addContainerGap()
            .addComponent(computersScrollPane, javax.swing.GroupLayout.PREFERRED_SIZE, 171, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(addComputerButton)
                .addComponent(editComputerButton)
                .addComponent(removeComputerButton))
            .addGap(24, 24, 24)
            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(serialNumberLabel)
                .addComponent(serialNumberTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(computerTypeLabel)
                .addComponent(computerTypeComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(18, 18, 18)
            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                .addComponent(brandLabel)
                .addComponent(brandTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addComponent(attributeLabel)
                .addComponent(attributeTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
            .addGap(18, 18, 18)
            .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(modelLabel)
                    .addComponent(modelTextField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(computersPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(saveButton)
                    .addComponent(cancelButton)))
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 30, Short.MAX_VALUE)
            .addComponent(messageLabel)
            .addContainerGap())
    );

    computerManagementTabbedPane.addTab("Computers", computersPanel);

    javax.swing.GroupLayout servicesPanelLayout = new javax.swing.GroupLayout(servicesPanel);
    servicesPanel.setLayout(servicesPanelLayout);
    servicesPanelLayout.setHorizontalGroup(
        servicesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 672, Short.MAX_VALUE)
    );
    servicesPanelLayout.setVerticalGroup(
        servicesPanelLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGap(0, 394, Short.MAX_VALUE)
    );

    computerManagementTabbedPane.addTab("Services", servicesPanel);

    javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
    getContentPane().setLayout(layout);
    layout.setHorizontalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
            .addComponent(computerManagementTabbedPane, javax.swing.GroupLayout.PREFERRED_SIZE, 672, javax.swing.GroupLayout.PREFERRED_SIZE)
            .addContainerGap())
        .addGroup(layout.createSequentialGroup()
            .addGap(240, 240, 240)
            .addComponent(computerManagementLabel)
            .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
    );
    layout.setVerticalGroup(
        layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
        .addGroup(layout.createSequentialGroup()
            .addGap(18, 18, 18)
            .addComponent(computerManagementLabel)
            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
            .addComponent(computerManagementTabbedPane)
            .addContainerGap())
    );

    pack();
    }// </editor-fold>//GEN-END:initComponents

    public void addRowTable(Vector row) {
        DefaultTableModel model = (DefaultTableModel) this.computersTable.getModel();
        model.addRow(row);
    }
    
     public void clearComputers() {
        DefaultTableModel model = (DefaultTableModel) this.computersTable.getModel();
        model.setRowCount(0);
        computersTable.clearSelection();
        computersTable.revalidate();
        computersTable.repaint();
    }
     
      public void clearTextFields() {
        this.serialNumberTextField.setText("");
        this.brandTextField.setText("");
        this.modelTextField.setText("");
        this.attributeTextField.setText("");
        this.computerTypeComboBox.setSelectedIndex(0);
    }
    private int lastSelectedRow = -1;
    
    public void setLastSelectedRow(int selection) {
        this.lastSelectedRow = selection;
    }
    
    public int getLastSelectedRow() {
        return this.lastSelectedRow;
    }
    
    public void addComputersScrollPaneMouseListener(MouseListener listener) {
        this.computersScrollPane.addMouseListener(listener);
    }
    
    private int selectedRow;
      
    public void clearSelection() {
        this.computersTable.clearSelection();
    }
      public String getComputerInfo(int row, int column) {
          String info = "";
          if(row >= 0 && column >= 0) {
            info = computersTable.getModel().getValueAt(row, column).toString();
        }
          
          return info;
      } 
      
      public boolean isRowSelected(boolean b) {
          if (computersTable.getSelectedRow() == -1) {
              return false;
          }
          
          return true;
      }
     
      public void setSelectedRow(int row) {
          this.selectedRow = row;
      }
    
    public void addComputerActionListener(ActionListener listener) {
        this.addComputerButton.addActionListener(listener);
    }
    
    public void addEditComputerActionListener(ActionListener listener) {
        this.editComputerButton.addActionListener(listener);
    }
    
    public void addRemoveComputerActionListener(ActionListener listener) {
        this.removeComputerButton.addActionListener(listener);
    }
    
    public void setAttributeLabelName(String name) {
        this.attributeLabel.setText(name);
    }
    public void setAttributeLabelVisibility(boolean status) {
        this.attributeLabel.setVisible(status);
    }
    
    public void setAttributeTextFieldVisibility(boolean status) {
        this.attributeTextField.setVisible(status);
    }
    
    public void addComputerTypeOptionActionListener(ActionListener listener) {
        this.computerTypeComboBox.addActionListener(listener);
    }
    
    public String getComputerTypeOption() {
        return this.computerTypeComboBox.getSelectedItem().toString();
    }
    
    public String getSerialNumberTextField() {
        return this.serialNumberTextField.getText();
    }
    
    public String getBrandTextField() {
        return this.brandTextField.getText();
    }
    
    public String getModelTextField() {
        return this.modelTextField.getText();
    }
    
    public String getComputerTypeComboBox() {
        return this.computerTypeComboBox.getSelectedItem().toString();
    }
    
    public String getAttributeTextField() {
        return this.attributeTextField.getText();
    }
    
    public int getSelectedRow() {
        return this.selectedRow = computersTable.getSelectedRow();
    }
    
    public int getSelectedColumn() {
        return this.computersTable.getSelectedColumn();
    }
    
    public void setSerialNumberTextField(String text) {
        this.serialNumberTextField.setText(text);
    }
    
    public void setBrandTextField(String text) {
        this.brandTextField.setText(text);
    }
    
    public void setModelTextField(String text) {
        this.modelTextField.setText(text);
    }
    
    public void setComputerTypeOption(int option) {
        this.computerTypeComboBox.setSelectedIndex(option);
    }
    
    public void setAttributeTextField(String text) {
        this.attributeTextField.setText(text);
    }
    
    public void setComputersScrollPaneEnable(boolean status) {
        this.computersScrollPane.setEnabled(status);
    }
    
    public boolean isComputerScrollPaneEnable() {
        return this.computersScrollPane.isEnabled();
    }
    
    public void setComputersTableEnable(boolean status) {
        this.computersTable.setEnabled(status);
    }
    
    public void setRemoveButtonEnable(boolean status) {
        this.removeComputerButton.setEnabled(status);
    }
    
    public void setEditButtonEnable(boolean status) {
        this.editComputerButton.setEnabled(status);
    }
    
    public void setAddButtonEnable(boolean status) {
        this.addComputerButton.setEnabled(status);
    }
  
    public void setSerialNumberTextFieldEnable(boolean status) {
        this.serialNumberTextField.setEnabled(status);
    }
    
    public void setBrandTextFieldEnable(boolean status) {
        this.brandTextField.setEnabled(status);
    }
    
    public void setModelTextFieldEnable(boolean status) {
        this.modelTextField.setEnabled(status);
    }
    
    public void setComputerTypeComboBoxEnable(boolean status) {
        this.computerTypeComboBox.setEnabled(status);
    }
    
    public void setAttributeTextFieldEnable(boolean status) {
        this.attributeTextField.setEnabled(status);
    }
    
    public void setSaveButtonEnable(boolean status) {
        this.saveButton.setEnabled(status);
    }
    
    public void setCancelButtonEnable(boolean status) {
        this.cancelButton.setEnabled(status);
    }
    
    public void addSaveButtonActionListener(ActionListener listener) {
        this.saveButton.addActionListener(listener);
    }
    
    public void addCancelButtonActionListener(ActionListener listener) {
        this.cancelButton.addActionListener(listener);
    }
    
    public void addComputersTableMouseListener(MouseListener listener) {
        this.computersTable.addMouseListener(listener);
    }
    
    public void setMessageLabelText(String text) {
        this.messageLabel.setText(text);
    }
   
    
    public boolean isAnyTextFieldBlank() {
        String[] textFields = {getSerialNumberTextField(), getBrandTextField(), 
            getModelTextField(), getAttributeTextField()
        };
        
        for(String tf : textFields) {
            if (tf.isBlank()) {
                return true;
            }
        }
        
        return false;
    }
    
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addComputerButton;
    private javax.swing.JLabel attributeLabel;
    private javax.swing.JTextField attributeTextField;
    private javax.swing.JLabel brandLabel;
    private javax.swing.JTextField brandTextField;
    private javax.swing.JButton cancelButton;
    private javax.swing.JLabel computerManagementLabel;
    private javax.swing.JTabbedPane computerManagementTabbedPane;
    private javax.swing.JComboBox<String> computerTypeComboBox;
    private javax.swing.JLabel computerTypeLabel;
    private javax.swing.JPanel computersPanel;
    private javax.swing.JScrollPane computersScrollPane;
    private javax.swing.JTable computersTable;
    private javax.swing.JButton editComputerButton;
    private javax.swing.JLabel messageLabel;
    private javax.swing.JLabel modelLabel;
    private javax.swing.JTextField modelTextField;
    private javax.swing.JButton removeComputerButton;
    private javax.swing.JButton saveButton;
    private javax.swing.JLabel serialNumberLabel;
    private javax.swing.JTextField serialNumberTextField;
    private javax.swing.JPanel servicesPanel;
    // End of variables declaration//GEN-END:variables
}
