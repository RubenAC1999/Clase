package com.example.gametracker.ui


import android.app.Application
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.gametracker.data.repository.AuthRepository
import com.example.gametracker.ui.navigation.Routes
import com.example.gametracker.ui.screens.AccountScreenContent
import com.example.gametracker.ui.screens.HomeScreenContent
import com.example.gametracker.ui.screens.ListScreenContent
import com.example.gametracker.ui.screens.LoginScreenContent
import com.example.gametracker.ui.screens.RegisterScreenContent
import com.example.gametracker.ui.viewmodel.AuthViewModel
import com.example.gametracker.ui.viewmodel.AuthViewModelFactory

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
                val currentUser by remember {mutableStateOf(AuthRepository.getCurrentUser()) }
                val authRepository = AuthRepository
                val application: Application = applicationContext as Application
                val viewModel: AuthViewModel by viewModels {
                    AuthViewModelFactory(application)
                }
                val navController = rememberNavController()
                LaunchedEffect(currentUser) {
                    if (currentUser != null) {
                        navController.navigate(Routes.LOGIN) {
                        }
                    }
                }

                NavHost(navController = navController, startDestination = Routes.LOGIN) {
                    composable(Routes.LOGIN) { LoginScreenContent(navController, viewModel) }
                    composable(Routes.REGISTER) { RegisterScreenContent(navController, viewModel) }
                    composable(Routes.HOME) { HomeScreenContent(navController) }
                    composable(Routes.ACCOUNT) { AccountScreenContent(navController) }
                    composable(Routes.LIST) { ListScreenContent(navController) }
                }
            }
        }
    }




