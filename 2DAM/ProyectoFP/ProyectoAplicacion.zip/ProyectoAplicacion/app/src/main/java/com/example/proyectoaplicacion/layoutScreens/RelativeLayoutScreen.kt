package com.example.proyectoaplicacion.layoutScreens

import android.os.Bundle
import androidx.activity.ComponentActivity
import com.example.proyectoaplicacion.R

class RelativeLayoutScreen : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.relativelayout)
    }
}