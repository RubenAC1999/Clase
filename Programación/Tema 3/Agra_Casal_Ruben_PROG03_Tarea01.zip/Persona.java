class Persona {

    // Declaramos las variables para la clase Persona
    String nombre;
    int edad;
    float altura;


    // Creamos un constructor para la clase Persona
    Persona(String nombre, int edad, float altura){
        this.nombre = nombre;
        this.edad = edad;
        this.altura = altura;
    }
    Persona(){
        this.nombre = "X";
        this.edad = -1;
        this.altura = -1f;
    }


    // Setters y getters de cada atributo

    // Para el nombre
    void setNombre(String nombre){
        this.nombre = nombre;
    }
    String getNombre(){
        return this.nombre;
    }

    // Para la edad
    void setEdad(int edad){
        this.edad = edad;
    }
    int getEdad(){
        return this.edad;
    }

    // Para la altura
    void setAltura(float altura){
        this.altura = altura;
    }
    float getAltura(){
        return this.altura;
    }


}
