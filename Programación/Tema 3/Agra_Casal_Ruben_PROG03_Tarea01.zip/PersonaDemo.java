
import java.util.Scanner;

class PersonaDemo {
    public static void main(String[] args){

        Scanner entrada = new Scanner(System.in);

        // Creamos nuevos objetos en base al constructor creado

        Persona persona1 = new Persona();
        Persona persona2 = new Persona ();

        System.out.println("Introduzca el nombre de la persona: ");
        persona1.setNombre(entrada.nextLine());

        System.out.println("Introduzca la edad de la persona: ");
        persona1.setEdad(entrada.nextInt());

        System.out.println("Introduzca la altura de la persona: ");
        persona1.setAltura(entrada.nextFloat());

        // Imprimimos los mensajes correspondientes
        
        System.out.println("-----------------------PERSONA 1-------------------");
        System.out.println("El nombre de la persona 1 es: " + persona1.getNombre());
        System.out.println("La edad de la persona 1 es: " + persona1.getEdad() + " años");
        System.out.printf("La altura de la persona 1 es: %.2f %n", persona1.getAltura());

        System.out.println("-----------------------PERSONA 2-------------------");
        System.out.println("El nombre de la persona 2 es: " + persona2.getNombre());
        System.out.println("La edad de la persona 2 es: " + persona2.getEdad() + " años");
        System.out.printf("La altura de la persona 2 es: %.2f ", persona2.getAltura());



    }

}
